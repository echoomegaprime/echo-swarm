from __future__ import annotations

import asyncio
import json
import os
import tempfile
from pathlib import Path
from typing import Any, Protocol

from .models import FusionResult


class MemoryAdapter(Protocol):
    async def retrieve(self, objective: str, limit: int = 20) -> list[dict[str, Any]]:
        ...

    async def write_run(self, result: FusionResult) -> list[str]:
        ...


class InMemoryMemoryAdapter:
    def __init__(self, seed: list[dict[str, Any]] | None = None) -> None:
        self.records: dict[str, dict[str, Any]] = {}
        self.seed = list(seed or [])
        self.write_attempts: list[str] = []

    async def retrieve(self, objective: str, limit: int = 20) -> list[dict[str, Any]]:
        persisted = list(self.records.values())
        return (self.seed + persisted)[-max(0, limit) :]

    async def write_run(self, result: FusionResult) -> list[str]:
        self.write_attempts.append(result.run_id)
        memory_id = f"run:{result.run_id}"
        self.records[result.run_id] = {
            "id": memory_id,
            "objective": result.provenance.get("objective", ""),
            "answer": result.answer,
            "confidence": result.confidence,
            "profile": result.provenance.get("profile"),
            "historical_parity": False,
        }
        return [memory_id]

class JsonFileMemoryAdapter:
    """Small idempotent local memory adapter keyed by run ID."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = asyncio.Lock()

    def _read(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"version": 1, "records": {}}
        with self.path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, dict) or not isinstance(data.get("records", {}), dict):
            raise ValueError("memory file has an invalid schema")
        return data

    def _atomic_write(self, data: dict[str, Any]) -> None:
        descriptor, temporary = tempfile.mkstemp(prefix=f".{self.path.name}.", suffix=".tmp", dir=self.path.parent)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
                json.dump(data, handle, indent=2, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    async def retrieve(self, objective: str, limit: int = 20) -> list[dict[str, Any]]:
        async with self._lock:
            data = await asyncio.to_thread(self._read)
        words = {word.lower() for word in objective.split() if len(word) > 3}
        records = list(data.get("records", {}).values())
        ranked = sorted(
            records,
            key=lambda item: sum(word in json.dumps(item).lower() for word in words),
            reverse=True,
        )
        return ranked[: max(0, limit)]

    async def write_run(self, result: FusionResult) -> list[str]:
        memory_id = f"run:{result.run_id}"
        async with self._lock:
            data = await asyncio.to_thread(self._read)
            records = data.setdefault("records", {})
            records[result.run_id] = {
                "id": memory_id,
                "objective": result.provenance.get("objective", ""),
                "answer": result.answer,
                "confidence": result.confidence,
                "major_findings": [item.to_dict() for item in result.major_findings],
                "dissent": [item.to_dict() for item in result.dissent],
                "unresolved": list(result.unresolved),
                "profile": result.provenance.get("profile"),
                "historical_parity": False,
            }
            await asyncio.to_thread(self._atomic_write, data)
        return [memory_id]
