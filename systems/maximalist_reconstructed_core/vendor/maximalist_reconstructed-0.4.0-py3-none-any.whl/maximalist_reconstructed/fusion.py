from __future__ import annotations

import asyncio
import json
import re
import time
import uuid
from collections import defaultdict
from statistics import mean
from typing import Any

from .capabilities import CapabilityOrchestrator
from .config import SeatConfig, SeatRegistry
from .control import (
    BudgetExceeded,
    BudgetPolicy,
    CostTable,
    DeadlineExceeded,
    ProviderCircuitOpen,
    RunCancelled,
    RunControlError,
    RunController,
    UncertainCallError,
)
from .memory import MemoryAdapter
from .models import (
    Contradiction,
    Dissent,
    Finding,
    FusionCandidate,
    FusionResult,
    HISTORICAL_PARITY,
    PROFILE_NAME,
    RankedFinding,
    Retask,
    SeatResult,
    clamp_probability,
)
from .parsing import parse_provider_output
from .providers import ProviderError, ProviderRegistry, ProviderRequest
from .state import JsonRunStateStore, RunState


PHASES = (
    "initialized",
    "memory_retrieved",
    "capabilities_grounded",
    "decomposed",
    "independent_pass",
    "findings_published",
    "retasked",
    "critiqued",
    "arbitrated",
    "fusion_pass",
    "finalized",
    "completed",
)


class RunPaused(RuntimeError):
    def __init__(self, run_id: str, phase: str) -> None:
        super().__init__(f"run {run_id} paused after {phase}")
        self.run_id = run_id
        self.phase = phase


class FusionEngine:
    """Restart-safe implementation of the recovered fusion.py orchestration contract."""

    def __init__(
        self,
        *,
        providers: ProviderRegistry,
        memory: MemoryAdapter,
        registry: SeatRegistry,
        state_store: JsonRunStateStore,
        max_fusion_passes: int = 3,
        convergence_threshold: float = 0.88,
        broadcast_threshold: float = 0.62,
        max_retasks: int = 8,
        max_critiques: int = 3,
        max_concurrency: int = 10,
        provider_mode: str = "live",
        budget_policy: BudgetPolicy | None = None,
        cost_table: CostTable | None = None,
        capabilities: CapabilityOrchestrator | None = None,
    ) -> None:
        if not 1 <= max_fusion_passes <= 10:
            raise ValueError("max_fusion_passes must be between 1 and 10")
        if not 1 <= max_concurrency <= 100:
            raise ValueError("max_concurrency must be between 1 and 100")
        registry.validate(require_seats=40)
        self.providers = providers
        self.memory = memory
        self.registry = registry
        self.state_store = state_store
        self.max_fusion_passes = max_fusion_passes
        self.convergence_threshold = clamp_probability(convergence_threshold, 0.88)
        self.broadcast_threshold = clamp_probability(broadcast_threshold, 0.62)
        self.max_retasks = max(0, max_retasks)
        self.max_critiques = max(0, max_critiques)
        self.max_concurrency = max_concurrency
        self.provider_mode = provider_mode
        self.budget_policy = budget_policy or BudgetPolicy(
            max_calls=100,
            max_input_tokens=250_000,
            max_output_tokens=100_000,
            max_estimated_cost_usd=0.0 if provider_mode == "deterministic_test" else 10.0,
            require_pricing=provider_mode != "deterministic_test",
        )
        self.cost_table = cost_table or CostTable(
            free_providers={"fake"} if provider_mode == "deterministic_test" else {"ollama"}
        )
        self.capabilities = capabilities
        self.performance: dict[str, dict[str, float]] = {}
        self._controllers: dict[str, RunController] = {}

    async def run(
        self,
        objective: str,
        context: dict[str, Any] | None = None,
        *,
        run_id: str | None = None,
        pause_after: str | None = None,
        selected_seat_ids: list[str] | None = None,
        selected_trinity_ids: list[str] | None = None,
        execution_mode: str | None = None,
    ) -> FusionResult:
        objective = objective.strip()
        if not objective:
            raise ValueError("objective must not be empty")
        if len(objective) > 100_000:
            raise ValueError("objective exceeds the 100000-character limit")
        caller_context = dict(context or {})
        json.dumps(caller_context)
        selected = list(dict.fromkeys(selected_seat_ids or [seat.id for seat in self.registry.enabled_seats]))
        configured = {seat.id for seat in self.registry.enabled_seats}
        unknown = [seat_id for seat_id in selected if seat_id not in configured]
        if unknown:
            raise ValueError(f"selected seat identifiers are not configured: {unknown}")
        if not selected:
            raise ValueError("at least one swarm seat must be selected")
        selected_trinity = list(
            dict.fromkeys(selected_trinity_ids or [seat.id for seat in self.registry.trinity])
        )
        configured_trinity = {seat.id for seat in self.registry.trinity}
        unknown_trinity = [seat_id for seat_id in selected_trinity if seat_id not in configured_trinity]
        if unknown_trinity:
            raise ValueError(f"selected Trinity identifiers are not configured: {unknown_trinity}")
        if not selected_trinity:
            raise ValueError("at least one Trinity seat must be selected")
        state = RunState(
            run_id=run_id or uuid.uuid4().hex,
            objective=objective,
            caller_context=caller_context,
            execution_mode=execution_mode or ("deterministic_test" if self.provider_mode == "deterministic_test" else "full"),
            selected_seat_ids=selected,
            selected_trinity_ids=selected_trinity,
            budget_policy=self.budget_policy,
            capability_profile=self.capabilities.profile if self.capabilities else "off",
            capability_mode=self.capabilities.mode if self.capabilities else "disabled",
            selected_capability_ids=(self.capabilities.selected_ids if self.capabilities else []),
        )
        self.state_store.save(state)
        return await self._drive(state, pause_after=pause_after)

    async def resume(self, run_id: str, *, pause_after: str | None = None) -> FusionResult:
        state = self.state_store.load(run_id)
        if not state.selected_trinity_ids:
            state.selected_trinity_ids = [seat.id for seat in self.registry.trinity]
        if state.status == "completed" and state.result is not None:
            return state.result
        controller = self._controller_for(state)
        try:
            controller.assert_resume_safe()
        except UncertainCallError:
            state.status = "blocked_uncertain"
            self.state_store.save(state)
            raise
        if state.cancel_requested_at is not None:
            state.status = "cancelled"
            self.state_store.save(state)
            raise RunCancelled(state.cancel_reason or "operator cancellation requested")
        state.status = "running"
        self.state_store.save(state)
        return await self._drive(state, pause_after=pause_after)

    async def _drive(self, state: RunState, *, pause_after: str | None) -> FusionResult:
        try:
            return await self._execute(state, pause_after=pause_after)
        except RunCancelled:
            state.status = "cancelled"
            self.state_store.save(state)
            raise
        except UncertainCallError:
            state.status = "blocked_uncertain"
            self.state_store.save(state)
            raise
        except BudgetExceeded:
            state.status = "blocked_budget"
            self.state_store.save(state)
            raise
        except DeadlineExceeded:
            state.status = "blocked_deadline"
            self.state_store.save(state)
            raise

    async def _execute(self, state: RunState, *, pause_after: str | None) -> FusionResult:
        if pause_after is not None and pause_after not in PHASES:
            raise ValueError(f"unknown pause phase: {pause_after}")

        if self._before(state, "memory_retrieved"):
            state.memories = await self.memory.retrieve(state.objective)
            state.memory_reads = [str(item.get("id", "unknown")) for item in state.memories]
            self._checkpoint(state, "memory_retrieved", pause_after)

        if self._before(state, "capabilities_grounded"):
            if state.selected_capability_ids:
                if self.capabilities is None:
                    raise RuntimeError(
                        "checkpoint requires capability adapters before capabilities_grounded"
                    )
                if state.selected_capability_ids != self.capabilities.selected_ids:
                    raise RuntimeError(
                        "configured capability identifiers do not match the restart-safe checkpoint"
                    )
                state.capability_results = await self.capabilities.gather(
                    run_id=state.run_id,
                    objective=state.objective,
                )
            else:
                state.capability_results = []
            self._checkpoint(state, "capabilities_grounded", pause_after)

        if self._before(state, "decomposed"):
            state.subproblems = await self._decompose(state)
            state.assignments = self._assign_seats(state.subproblems, state.selected_seat_ids)
            self._checkpoint(state, "decomposed", pause_after)

        if self._before(state, "independent_pass"):
            state.first_pass = await self._independent_pass(state)
            state.finding_bus = [finding for result in state.first_pass for finding in result.findings]
            self._checkpoint(state, "independent_pass", pause_after)

        if self._before(state, "findings_published"):
            state.contradictions, state.dissent = self._detect_conflicts(state.finding_bus)
            state.shared_findings = self._select_broadcast_findings(state.finding_bus)
            state.retasks = self._generate_retasks(
                state.shared_findings,
                state.contradictions,
                state.dissent,
                state.assignments,
            )
            self._checkpoint(state, "findings_published", pause_after)

        if self._before(state, "retasked"):
            state.retask_results = await self._execute_retasks(state)
            state.finding_bus.extend(finding for result in state.retask_results for finding in result.findings)
            state.contradictions, state.dissent = self._detect_conflicts(state.finding_bus)
            self._checkpoint(state, "retasked", pause_after)

        if self._before(state, "critiqued"):
            state.critique_results = await self._critique(state)
            state.finding_bus.extend(finding for result in state.critique_results for finding in result.findings)
            state.contradictions, state.dissent = self._detect_conflicts(state.finding_bus)
            self._checkpoint(state, "critiqued", pause_after)

        if self._before(state, "arbitrated"):
            state.ranked = self._arbitrate(state.finding_bus)
            self._checkpoint(state, "arbitrated", pause_after)

        if state.last_completed_phase in {"arbitrated", "fusion_pass"}:
            await self._recursive_fusion(state, pause_after=pause_after)

        if self._before(state, "finalized"):
            if state.candidate is None:
                raise RuntimeError("fusion produced no candidate")
            state.result = self._build_result(state)
            state.status = "finalized"
            self._checkpoint(state, "finalized", pause_after)

        if state.last_completed_phase == "finalized":
            if state.result is None:
                raise RuntimeError("finalized checkpoint has no result")
            state.result.memory_writes = await self.memory.write_run(state.result)
            state.result.performance_updates = self._update_performance(state)
            state.status = "completed"
            self._checkpoint(state, "completed", pause_after=None)

        if state.result is None:
            raise RuntimeError("run completed without a result")
        return state.result

    @staticmethod
    def _before(state: RunState, phase: str) -> bool:
        current = PHASES.index(state.last_completed_phase)
        target = PHASES.index(phase)
        return current < target

    def _checkpoint(self, state: RunState, phase: str, pause_after: str | None) -> None:
        state.last_completed_phase = phase
        if pause_after == phase:
            state.status = "paused"
        self.state_store.save(state)
        if pause_after == phase:
            raise RunPaused(state.run_id, phase)

    def _controller_for(self, state: RunState) -> RunController:
        controller = self._controllers.get(state.run_id)
        if controller is not None:
            return controller

        def cancellation() -> tuple[bool, str | None]:
            requested, reason = self.state_store.cancellation(state.run_id)
            if requested:
                state.cancel_requested_at = state.cancel_requested_at or time.time()
                state.cancel_reason = reason
            return requested, reason

        controller = RunController(
            policy=state.budget_policy,
            ledger=state.execution_ledger,
            costs=self.cost_table,
            persist=lambda: self.state_store.save(state),
            cancellation=cancellation,
        )
        self._controllers[state.run_id] = controller
        return controller

    def _base_context(self, state: RunState) -> dict[str, Any]:
        reserved = {
            "visible_findings",
            "peer_outputs",
            "raw_outputs",
            "ranked_findings",
            "contradictions",
            "dissent",
            "fusion_pass",
            "previous_candidate",
            "capability_evidence",
        }
        caller = {key: value for key, value in state.caller_context.items() if key not in reserved}
        return {
            "objective": state.objective,
            "memories": state.memories,
            "capability_evidence": [
                item.to_context()
                for item in state.capability_results
                if item.status == "completed"
            ],
            "caller_context": caller,
            "profile": PROFILE_NAME,
            "historical_parity": HISTORICAL_PARITY,
        }

    async def _call(
        self,
        state: RunState,
        seat: SeatConfig,
        *,
        prompt: str,
        context: dict[str, Any],
        phase: str,
    ) -> str:
        structured_context = json.dumps(
            context,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        wire_prompt = f"{prompt}\n\nSTRUCTURED_CONTEXT_JSON:\n{structured_context}"
        request = ProviderRequest(
            provider=seat.provider,
            seat_id=seat.id,
            model=seat.model,
            role=seat.role,
            prompt=wire_prompt,
            context=context,
            phase=phase,
            max_output_tokens=state.budget_policy.max_output_tokens_per_call,
        )
        adapter, resolved = self.providers.prepare(request)
        controller = self._controller_for(state)
        last_error: Exception | None = None
        for attempt in range(1, state.budget_policy.retry_limit + 2):
            try:
                return await controller.execute_attempt(
                    provider=resolved.provider,
                    model=resolved.model,
                    seat_id=resolved.seat_id,
                    phase=resolved.phase,
                    attempt=attempt,
                    prompt=resolved.prompt,
                    max_output_tokens=resolved.max_output_tokens,
                    operation=lambda: self.providers.invoke(adapter, resolved),
                )
            except RunControlError:
                raise
            except ProviderCircuitOpen as exc:
                raise ProviderError(str(exc), retryable=False) from exc
            except Exception as exc:
                last_error = exc
                if not bool(getattr(exc, "retryable", False)) or attempt > state.budget_policy.retry_limit:
                    raise
                await asyncio.sleep(state.budget_policy.retry_backoff_seconds * (2 ** (attempt - 1)))
        assert last_error is not None
        raise last_error

    async def _decompose(self, state: RunState) -> list[str]:
        prompt = (
            "Decompose the objective into independently useful subproblems. "
            'Return JSON only using {"subproblems":["bounded subproblem", "..."]}.\n\n'
            f"OBJECTIVE:\n{state.objective}"
        )
        raw = await self._call(
            state,
            self.registry.planner,
            prompt=prompt,
            context={**self._base_context(state), "visible_findings": []},
            phase="decompose",
        )
        problems = self._parse_subproblems(raw)
        deduplicated = list(dict.fromkeys(problems))
        return deduplicated[:40] or [state.objective]

    @staticmethod
    def _parse_subproblems(raw: str) -> list[str]:
        """Accept bounded JSON or legacy one-subproblem-per-line planner output."""

        cleaned = re.sub(r"^\s*```(?:json)?\s*|\s*```\s*$", "", raw.strip(), flags=re.IGNORECASE)
        try:
            value = json.loads(cleaned)
        except json.JSONDecodeError:
            value = None

        candidates: Any = None
        if isinstance(value, list):
            candidates = value
        elif isinstance(value, dict):
            for key in ("subproblems", "problems", "tasks"):
                if isinstance(value.get(key), list):
                    candidates = value[key]
                    break

        problems: list[str] = []
        if isinstance(candidates, list):
            for item in candidates:
                if isinstance(item, str):
                    text = item.strip()
                elif isinstance(item, dict):
                    text = str(
                        item.get("subproblem")
                        or item.get("problem")
                        or item.get("task")
                        or item.get("title")
                        or ""
                    ).strip()
                else:
                    text = ""
                if text:
                    problems.append(text)
            return problems

        return [
            line.strip(" -\t")
            for line in cleaned.splitlines()
            if line.strip(" -\t") and line.strip() not in {"{", "}", "[", "]"}
        ]

    def _assign_seats(self, subproblems: list[str], selected_seat_ids: list[str]) -> list[dict[str, Any]]:
        selected = set(selected_seat_ids)
        return [
            {**seat.to_dict(), "subproblem": subproblems[index % len(subproblems)]}
            for index, seat in enumerate(seat for seat in self.registry.enabled_seats if seat.id in selected)
        ]

    async def _independent_pass(self, state: RunState) -> list[SeatResult]:
        semaphore = asyncio.Semaphore(self.max_concurrency)

        async def execute(assignment: dict[str, Any]) -> SeatResult:
            seat = self.registry.get(assignment["id"])
            prompt = self._finding_prompt(
                seat=seat,
                objective=state.objective,
                subproblem=assignment["subproblem"],
                phase="independent first pass",
                instruction="Do not assume or infer what any other seat thinks. Produce your own analysis.",
            )
            context = {
                **self._base_context(state),
                "phase": "independent",
                "subproblem": assignment["subproblem"],
                "visible_findings": [],
            }
            async with semaphore:
                return await self._execute_seat(
                    state,
                    seat,
                    subproblem=assignment["subproblem"],
                    prompt=prompt,
                    context=context,
                    phase="independent",
                )

        return await self._collect_seat_results(*(execute(assignment) for assignment in state.assignments))

    @staticmethod
    def _finding_prompt(
        *, seat: SeatConfig,
        objective: str,
        subproblem: str,
        phase: str,
        instruction: str,
    ) -> str:
        return f"""You are {seat.id}, role {seat.role}.
Phase: {phase}
Objective: {objective}
Subproblem: {subproblem}
{instruction}

Return one JSON object only:
{{"analysis":"...","findings":[{{"claim":"...","topic":"...","stance":"supports|opposes|neutral","evidence":["..."],"source_refs":["..."],"confidence":0.0,"novelty":0.0,"importance":0.0}}]}}
Do not include secrets or hidden reasoning. Evidence must be concise and attributable."""

    async def _execute_seat(
        self,
        state: RunState,
        seat: SeatConfig,
        *,
        subproblem: str,
        prompt: str,
        context: dict[str, Any],
        phase: str,
    ) -> SeatResult:
        started = time.perf_counter()
        try:
            raw = await self._call(state, seat, prompt=prompt, context=context, phase=phase)
            parsed = parse_provider_output(
                raw,
                seat_id=seat.id,
                model=seat.model,
                role=seat.role,
                subproblem=subproblem,
                phase=phase,
            )
            confidence = mean(finding.confidence for finding in parsed.findings) if parsed.findings else 0.0
            return SeatResult(
                seat_id=seat.id,
                model=seat.model,
                role=seat.role,
                subproblem=subproblem,
                raw_output=raw,
                findings=parsed.findings,
                confidence=confidence,
                latency_ms=int((time.perf_counter() - started) * 1000),
                phase=phase,
            )
        except RunControlError:
            raise
        except Exception as exc:
            return SeatResult(
                seat_id=seat.id,
                model=seat.model,
                role=seat.role,
                subproblem=subproblem,
                raw_output="",
                findings=[],
                latency_ms=int((time.perf_counter() - started) * 1000),
                error=f"{type(exc).__name__}: {exc}",
                phase=phase,
            )

    @staticmethod
    async def _collect_seat_results(*operations: Any) -> list[SeatResult]:
        """Let started calls settle, then propagate run controls without hiding seat failures."""

        responses = await asyncio.gather(*operations, return_exceptions=True)
        for response in responses:
            if isinstance(response, RunControlError):
                raise response
        for response in responses:
            if isinstance(response, BaseException):
                raise response
        return [response for response in responses if isinstance(response, SeatResult)]

    def _select_broadcast_findings(self, findings: list[Finding]) -> list[Finding]:
        selected: list[Finding] = []
        seen: set[str] = set()
        for ranked in self._arbitrate(findings):
            finding = ranked.finding
            high_value = ranked.score >= self.broadcast_threshold
            exceptional = finding.importance >= 0.9 or finding.novelty >= 0.9 or finding.verified or finding.contradicted
            if (high_value or exceptional) and finding.finding_id not in seen:
                selected.append(finding)
                seen.add(finding.finding_id)
        return selected[:40]

    @staticmethod
    def _topic_key(topic: str) -> str:
        return re.sub(r"[^a-z0-9]+", " ", topic.lower()).strip()

    def _detect_conflicts(self, findings: list[Finding]) -> tuple[list[Contradiction], list[Dissent]]:
        groups: dict[str, dict[str, list[Finding]]] = defaultdict(lambda: {"supports": [], "opposes": [], "neutral": []})
        for finding in findings:
            groups[self._topic_key(finding.topic)][finding.stance].append(finding)
        contradictions: list[Contradiction] = []
        dissent: list[Dissent] = []
        for topic, positions in groups.items():
            supporting = positions["supports"]
            opposing = positions["opposes"]
            if not supporting or not opposing:
                continue
            for finding in (*supporting, *opposing):
                finding.contradicted = True
            contradictions.append(
                Contradiction(
                    topic=topic,
                    supporting_claims=[item.claim for item in supporting],
                    opposing_claims=[item.claim for item in opposing],
                    supporting_seats=sorted({item.seat_id for item in supporting}),
                    opposing_seats=sorted({item.seat_id for item in opposing}),
                    evidence=list(dict.fromkeys(piece for item in (*supporting, *opposing) for piece in item.evidence)),
                )
            )
            if len(supporting) == len(opposing):
                minority, majority_label = supporting, "unresolved tie: supports and opposes"
            elif len(supporting) < len(opposing):
                minority, majority_label = supporting, "opposes"
            else:
                minority, majority_label = opposing, "supports"
            dissent.append(
                Dissent(
                    claim="; ".join(item.claim for item in minority),
                    dissenting_seats=sorted({item.seat_id for item in minority}),
                    majority_position=majority_label,
                    evidence=list(dict.fromkeys(piece for item in minority for piece in item.evidence)),
                    confidence=max(item.confidence for item in minority),
                    topic=topic,
                    reason_rejected="numerical minority; retained for evidence-weighted arbitration",
                )
            )
        return contradictions, dissent

    def _generate_retasks(
        self,
        shared: list[Finding],
        contradictions: list[Contradiction],
        dissent: list[Dissent],
        assignments: list[dict[str, Any]],
    ) -> list[Retask]:
        if self.max_retasks == 0:
            return []
        specialists = [
            item
            for item in assignments
            if any(token in item["role"] for token in ("verifier", "critic", "skeptic", "security", "provenance"))
        ] or assignments
        by_topic: dict[str, list[Finding]] = defaultdict(list)
        for finding in shared:
            by_topic[self._topic_key(finding.topic)].append(finding)
        retasks: list[Retask] = []
        used: set[tuple[str, str]] = set()
        priority_topics = [item.topic for item in contradictions] + [self._topic_key(item.topic) for item in shared]
        for topic in priority_topics:
            findings = by_topic.get(self._topic_key(topic), [])
            if not findings:
                findings = [item for item in shared if self._topic_key(item.topic) == self._topic_key(topic)]
            if not findings:
                continue
            source_seats = {item.seat_id for item in findings}
            candidate = next(
                (
                    item
                    for item in specialists
                    if item["id"] not in source_seats and (item["id"], topic) not in used
                ),
                None,
            )
            if candidate is None:
                continue
            used.add((candidate["id"], topic))
            conflict = any(self._topic_key(item.topic) == self._topic_key(topic) for item in contradictions)
            retasks.append(
                Retask(
                    seat_id=candidate["id"],
                    subproblem=f"Verify, refute, or extend the propagated finding topic: {topic}",
                    reason="explicit contradiction" if conflict else "high-value finding propagation",
                    findings_to_inspect=findings[:6],
                    kind="verify" if conflict else "extend",
                )
            )
            if len(retasks) >= self.max_retasks:
                break
        return retasks

    async def _execute_retasks(self, state: RunState) -> list[SeatResult]:
        async def execute(retask: Retask) -> SeatResult:
            seat = self.registry.get(retask.seat_id)
            prompt = self._finding_prompt(
                seat=seat,
                objective=state.objective,
                subproblem=retask.subproblem,
                phase="dynamic retask",
                instruction=f"Reason: {retask.reason}. Inspect only the structured findings supplied in context.",
            )
            context = {
                **self._base_context(state),
                "phase": "retask",
                "retask_kind": retask.kind,
                "visible_findings": [item.to_dict() for item in retask.findings_to_inspect],
            }
            return await self._execute_seat(
                state,
                seat,
                subproblem=retask.subproblem,
                prompt=prompt,
                context=context,
                phase="retask",
            )

        return await self._collect_seat_results(*(execute(retask) for retask in state.retasks)) if state.retasks else []

    async def _critique(self, state: RunState) -> list[SeatResult]:
        candidates = [
            item
            for item in state.assignments
            if any(token in item["role"] for token in ("critic", "skeptic", "security", "provenance"))
        ][: self.max_critiques]
        visible = self._select_broadcast_findings(state.finding_bus)[:12]

        async def execute(assignment: dict[str, Any]) -> SeatResult:
            seat = self.registry.get(assignment["id"])
            subproblem = "Critique the strongest structured claims, contradictions, and missing evidence"
            prompt = self._finding_prompt(
                seat=seat,
                objective=state.objective,
                subproblem=subproblem,
                phase="cross-model critique",
                instruction="Challenge unsupported claims and preserve justified dissent.",
            )
            return await self._execute_seat(
                state,
                seat,
                subproblem=subproblem,
                prompt=prompt,
                context={
                    **self._base_context(state),
                    "phase": "critique",
                    "visible_findings": [item.to_dict() for item in visible],
                    "contradictions": [item.to_dict() for item in state.contradictions],
                    "dissent": [item.to_dict() for item in state.dissent],
                },
                phase="critique",
            )

        return await self._collect_seat_results(*(execute(item) for item in candidates)) if candidates else []

    def _arbitrate(self, findings: list[Finding]) -> list[RankedFinding]:
        ranked: list[RankedFinding] = []
        for finding in findings:
            evidence_quality = min(1.0, 0.25 * len(finding.evidence) + 0.25 * len(finding.source_refs))
            verification = 1.0 if finding.verified else min(0.7, 0.2 * len(finding.verification_notes))
            performance = self.performance.get(finding.model, {}).get("domain_score", 0.5)
            components = {
                "evidence": evidence_quality,
                "confidence": finding.confidence,
                "importance": finding.importance,
                "novelty": finding.novelty,
                "verification": verification,
                "historical_performance": performance,
            }
            score = (
                0.34 * evidence_quality
                + 0.22 * finding.confidence
                + 0.16 * finding.importance
                + 0.10 * finding.novelty
                + 0.12 * verification
                + 0.06 * performance
            )
            ranked.append(RankedFinding(finding=finding, score=round(score, 6), score_components=components))
        return sorted(ranked, key=lambda item: (-item.score, item.finding.seat_id, item.finding.claim))

    async def _recursive_fusion(self, state: RunState, *, pause_after: str | None) -> None:
        while state.fusion_passes < self.max_fusion_passes:
            next_pass = state.fusion_passes + 1
            candidate = await self._trinity_fuse(state, fusion_pass=next_pass)
            state.candidate = candidate
            state.fusion_passes = next_pass
            converged = candidate.confidence >= self.convergence_threshold and not candidate.weak_claims
            if not converged:
                verification_results = await self._verify_candidate(state, candidate)
                state.verification_results.extend(verification_results)
                new_findings = [finding for result in verification_results for finding in result.findings]
                if new_findings:
                    state.finding_bus.extend(new_findings)
                    state.contradictions, state.dissent = self._detect_conflicts(state.finding_bus)
                    state.ranked = self._arbitrate(state.finding_bus)
            self._checkpoint(state, "fusion_pass", pause_after)
            if converged or not candidate.weak_claims:
                break
            if not new_findings:
                break

    async def _trinity_fuse(self, state: RunState, *, fusion_pass: int) -> FusionCandidate:
        structured_context = {
            **self._base_context(state),
            "phase": "trinity",
            "fusion_pass": fusion_pass,
            "ranked_findings": [item.to_dict() for item in state.ranked[:20]],
            "contradictions": [item.to_dict() for item in state.contradictions[:20]],
            "dissent": [item.to_dict() for item in state.dissent[:20]],
            "previous_candidate": state.candidate.to_dict() if state.candidate else None,
            "visible_findings": [item.finding.to_dict() for item in state.ranked[:20]],
        }

        async def execute(seat: SeatConfig) -> dict[str, Any]:
            prompt = (
                f"You are separate Trinity seat {seat.id} ({seat.role}). Synthesize only the bounded structured evidence "
                "in context. Preserve unresolved dissent. Return JSON with answer, confidence, supported_claims, "
                "weak_claims, and unresolved. Do not claim historical parity."
            )
            raw = await self._call(state, seat, prompt=prompt, context=structured_context, phase="trinity")
            return self._parse_candidate_mapping(raw, seat.id)

        selected = set(state.selected_trinity_ids)
        trinity = [seat for seat in self.registry.trinity if seat.id in selected]
        responses = await asyncio.gather(*(execute(seat) for seat in trinity), return_exceptions=True)
        for response in responses:
            if isinstance(response, RunControlError):
                raise response
        views = [item for item in responses if isinstance(item, dict)]
        if not views:
            errors = [str(item) for item in responses if isinstance(item, BaseException)]
            raise RuntimeError(f"all Trinity seats failed: {errors}")
        confidence = mean(clamp_probability(item.get("confidence", 0.0)) for item in views)
        proposed_supported = list(
            dict.fromkeys(
                claim for item in views for claim in self._list_field(item, "supported_claims")
            )
        )
        ranked_claims = [item.finding.claim for item in state.ranked]
        supported = [
            claim
            for claim in proposed_supported
            if any(self._claims_grounded(claim, ranked_claim) for ranked_claim in ranked_claims)
        ]
        ungrounded = [claim for claim in proposed_supported if claim not in supported]
        weak = list(dict.fromkeys(claim for item in views for claim in self._list_field(item, "weak_claims")))
        unresolved = list(dict.fromkeys(claim for item in views for claim in self._list_field(item, "unresolved")))
        if not ranked_claims:
            weak.append("No parsed seat findings were available for evidence-grounded fusion.")
            unresolved.append("Trinity synthesis could not be grounded in arbitrated seat findings.")
            answer = "No evidence-grounded synthesis was produced."
            confidence = min(confidence, 0.2)
        elif not supported:
            weak.append("No Trinity supported claim mapped to an arbitrated seat finding.")
            unresolved.append("Trinity output requires claim-level grounding before acceptance.")
            answer = "\n".join(f"- {claim}" for claim in ranked_claims[:5])
            confidence = min(confidence, 0.49)
        else:
            answer = "\n".join(f"- {claim}" for claim in supported)
            if ungrounded:
                unresolved.append(
                    f"{len(ungrounded)} Trinity-supported claim(s) were excluded as ungrounded."
                )
                confidence = min(confidence, 0.79)
        return FusionCandidate(
            answer=answer,
            confidence=confidence,
            supported_claims=supported,
            weak_claims=weak,
            unresolved=unresolved,
            trinity_views=views,
        )

    @staticmethod
    def _claims_grounded(candidate: str, source: str) -> bool:
        def tokens(value: str) -> set[str]:
            return {
                token
                for token in re.findall(r"[a-z0-9]+", value.lower())
                if len(token) > 2
            }

        candidate_normalized = " ".join(candidate.lower().split())
        source_normalized = " ".join(source.lower().split())
        if candidate_normalized == source_normalized:
            return True
        if candidate_normalized in source_normalized or source_normalized in candidate_normalized:
            return min(len(candidate_normalized), len(source_normalized)) >= 24
        candidate_tokens = tokens(candidate)
        source_tokens = tokens(source)
        if not candidate_tokens or not source_tokens:
            return False
        return len(candidate_tokens & source_tokens) / len(candidate_tokens | source_tokens) >= 0.6

    @staticmethod
    def _parse_candidate_mapping(raw: str, seat_id: str) -> dict[str, Any]:
        cleaned = re.sub(r"^\s*```(?:json)?\s*|\s*```\s*$", "", raw.strip(), flags=re.IGNORECASE)
        try:
            value = json.loads(cleaned)
        except json.JSONDecodeError:
            start, end = cleaned.find("{"), cleaned.rfind("}")
            if start < 0 or end <= start:
                raise ValueError(f"Trinity seat {seat_id} returned invalid JSON")
            value = json.loads(cleaned[start : end + 1])
        if not isinstance(value, dict) or not str(value.get("answer", "")).strip():
            raise ValueError(f"Trinity seat {seat_id} returned an invalid candidate")
        answer = value["answer"]
        if isinstance(answer, dict) and isinstance(answer.get("claims"), list):
            claims = [str(item).strip() for item in answer["claims"] if str(item).strip()]
            value["answer"] = "\n".join(f"- {claim}" for claim in claims)
        elif not isinstance(answer, str):
            value["answer"] = json.dumps(answer, sort_keys=True)
        if "unresolved" not in value and "unresolved_claims" in value:
            value["unresolved"] = value["unresolved_claims"]
        value["seat_id"] = seat_id
        return value

    @staticmethod
    def _list_field(mapping: dict[str, Any], key: str) -> list[str]:
        value = mapping.get(key, [])
        if isinstance(value, str):
            return [value] if value.strip() else []
        if isinstance(value, list):
            return [
                str(item.get("claim") or item.get("text") or json.dumps(item, sort_keys=True))
                if isinstance(item, dict)
                else json.dumps(item, sort_keys=True)
                if isinstance(item, list)
                else str(item)
                for item in value
                if str(item).strip()
            ]
        return []

    async def _verify_candidate(self, state: RunState, candidate: FusionCandidate) -> list[SeatResult]:
        specialists = [
            assignment
            for assignment in state.assignments
            if any(token in assignment["role"] for token in ("verifier", "critic", "skeptic", "security", "provenance"))
        ] or state.assignments
        weak_claims = candidate.weak_claims[: min(3, len(specialists))]

        async def execute(index: int, weak_claim: str) -> SeatResult:
            assignment = specialists[index]
            seat = self.registry.get(assignment["id"])
            subproblem = f"Verify or refute the weak fusion claim: {weak_claim}"
            prompt = self._finding_prompt(
                seat=seat,
                objective=state.objective,
                subproblem=subproblem,
                phase="fusion verification",
                instruction="Return corrected evidence as a structured finding. Do not merely restate the candidate.",
            )
            return await self._execute_seat(
                state,
                seat,
                subproblem=subproblem,
                prompt=prompt,
                context={
                    **self._base_context(state),
                    "phase": "verify",
                    "candidate": candidate.to_dict(),
                    "weak_claim": weak_claim,
                    "visible_findings": [item.finding.to_dict() for item in state.ranked[:12]],
                },
                phase="verify",
            )

        return (
            await self._collect_seat_results(*(execute(index, claim) for index, claim in enumerate(weak_claims)))
            if weak_claims
            else []
        )

    def _build_result(self, state: RunState) -> FusionResult:
        assert state.candidate is not None
        trinity_ids = {
            str(view.get("seat_id"))
            for view in state.candidate.trinity_views
            if isinstance(view, dict) and view.get("seat_id")
        }
        models_used = sorted(
            {finding.model for finding in state.finding_bus}
            | {seat.model for seat in self.registry.trinity if seat.id in trinity_ids}
            | {self.registry.planner.model}
        )
        return FusionResult(
            run_id=state.run_id,
            answer=state.candidate.answer,
            confidence=state.candidate.confidence,
            major_findings=[item.finding for item in state.ranked[:20]],
            dissent=state.dissent,
            unresolved=state.candidate.unresolved,
            models_used=models_used,
            retasks=state.retasks,
            fusion_passes=state.fusion_passes,
            memory_reads=state.memory_reads,
            memory_writes=[],
            provenance={
                "profile": PROFILE_NAME,
                "historical_parity": HISTORICAL_PARITY,
                "source_contract": "recovered fusion.py logic from referenced Emergence Research conversation",
                "objective": state.objective,
                "provider_mode": self.provider_mode,
                "deterministic_test_output": self.provider_mode == "deterministic_test",
                "execution_mode": state.execution_mode,
                "seat_count": len(state.selected_seat_ids),
                "configured_seat_count": len(self.registry.enabled_seats),
                "selected_seat_ids": list(state.selected_seat_ids),
                "selected_trinity_ids": list(state.selected_trinity_ids),
                "trinity_separate": True,
                "budget_policy": state.budget_policy.to_dict(),
                "execution_ledger": {
                    "calls_started": state.execution_ledger.calls_started,
                    "calls_completed": state.execution_ledger.calls_completed,
                    "calls_failed": state.execution_ledger.calls_failed,
                    "input_tokens_reserved": state.execution_ledger.input_tokens_reserved,
                    "input_tokens_observed": state.execution_ledger.input_tokens_observed,
                    "cached_input_tokens_observed": state.execution_ledger.cached_input_tokens_observed,
                    "output_tokens_reserved": state.execution_ledger.output_tokens_reserved,
                    "output_tokens_observed": state.execution_ledger.output_tokens_observed,
                    "estimated_cost_usd_reserved": state.execution_ledger.estimated_cost_usd_reserved,
                    "budget_exceeded_reason": state.execution_ledger.budget_exceeded_reason,
                    "uncertain_call_ids": [
                        item.call_id for item in state.execution_ledger.uncertain_calls
                    ],
                },
                "timestamp": time.time(),
                "capability_profile": state.capability_profile,
                "capability_mode": state.capability_mode,
                "selected_capability_ids": list(state.selected_capability_ids),
                "completed_capability_ids": [
                    item.capability_id
                    for item in state.capability_results
                    if item.status == "completed"
                ],
                "degraded_capability_ids": [
                    item.capability_id
                    for item in state.capability_results
                    if item.status not in {"completed", "skipped"}
                ],
                "capability_evidence_is_external_data": True,
            },
            contradictions=state.contradictions,
            capability_results=state.capability_results,
        )

    def _update_performance(self, state: RunState) -> list[dict[str, Any]]:
        updates: list[dict[str, Any]] = []
        results = state.first_pass + state.retask_results + state.critique_results + state.verification_results
        for result in results:
            stats = self.performance.setdefault(
                result.model,
                {"requests": 0.0, "successes": 0.0, "verified_findings": 0.0, "domain_score": 0.5},
            )
            stats["requests"] += 1
            stats["successes"] += 0 if result.error else 1
            stats["verified_findings"] += sum(1 for finding in result.findings if finding.verified)
            success_rate = stats["successes"] / stats["requests"]
            stats["domain_score"] = round(0.5 * stats["domain_score"] + 0.5 * success_rate, 6)
            updates.append({"model": result.model, **stats})
        return updates
