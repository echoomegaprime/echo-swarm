from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


ROLE_FAMILIES = (
    "planner",
    "decomposer",
    "general_reasoner",
    "researcher",
    "coder",
    "mathematician",
    "systems_architect",
    "memory_specialist",
    "critic",
    "adversarial_critic",
    "skeptic",
    "verifier",
    "security_reviewer",
    "creative_alternate",
    "historical_context",
    "provenance_auditor",
    "integration_specialist",
    "risk_analyst",
    "causal_analyst",
    "synthesis_reviewer",
)


@dataclass(frozen=True, slots=True)
class SeatConfig:
    id: str
    provider: str
    model: str
    role: str
    domains: tuple[str, ...] = ()
    enabled: bool = True

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SeatConfig":
        return cls(
            id=str(data["id"]),
            provider=str(data["provider"]),
            model=str(data["model"]),
            role=str(data["role"]),
            domains=tuple(str(item) for item in data.get("domains", [])),
            enabled=bool(data.get("enabled", True)),
        )

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["domains"] = list(self.domains)
        return data


@dataclass(frozen=True, slots=True)
class SeatRegistry:
    seats: tuple[SeatConfig, ...]
    trinity: tuple[SeatConfig, ...]
    planner: SeatConfig

    @classmethod
    def from_dict(cls, data: dict[str, Any], *, require_seats: int | None = 40) -> "SeatRegistry":
        if data.get("profile", "MAXIMALIST_RECONSTRUCTED") != "MAXIMALIST_RECONSTRUCTED":
            raise ValueError("seat registry profile must be MAXIMALIST_RECONSTRUCTED")
        if data.get("historical_parity", False) is not False:
            raise ValueError("seat registry must not claim historical parity")
        registry = cls(
            seats=tuple(SeatConfig.from_dict(item) for item in data.get("seats", [])),
            trinity=tuple(SeatConfig.from_dict(item) for item in data.get("trinity", [])),
            planner=SeatConfig.from_dict(
                data.get(
                    "planner",
                    {"id": "planner", "provider": "fake", "model": "fake-planner", "role": "planner"},
                )
            ),
        )
        registry.validate(require_seats=require_seats)
        return registry

    @classmethod
    def load(cls, path: str | Path, *, require_seats: int | None = 40) -> "SeatRegistry":
        with Path(path).open("r", encoding="utf-8") as handle:
            return cls.from_dict(json.load(handle), require_seats=require_seats)

    def validate(self, *, require_seats: int | None = 40) -> None:
        enabled = self.enabled_seats
        if require_seats is not None and len(enabled) != require_seats:
            raise ValueError(f"expected {require_seats} enabled seats, found {len(enabled)}")
        identifiers = [seat.id for seat in (*self.seats, *self.trinity, self.planner)]
        if len(identifiers) != len(set(identifiers)):
            raise ValueError("seat, Trinity, and planner identifiers must be unique")
        if len(self.trinity) != 3:
            raise ValueError("Trinity must contain exactly three configured seats")
        for seat in (*self.seats, *self.trinity, self.planner):
            if not all((seat.id, seat.provider, seat.model, seat.role)):
                raise ValueError("seat id, provider, model, and role must be non-empty")

    @property
    def enabled_seats(self) -> tuple[SeatConfig, ...]:
        return tuple(seat for seat in self.seats if seat.enabled)

    def get(self, seat_id: str) -> SeatConfig:
        for seat in (*self.seats, *self.trinity, self.planner):
            if seat.id == seat_id:
                return seat
        raise KeyError(seat_id)

    def to_dict(self) -> dict[str, Any]:
        return {
            "profile": "MAXIMALIST_RECONSTRUCTED",
            "historical_parity": False,
            "planner": self.planner.to_dict(),
            "seats": [seat.to_dict() for seat in self.seats],
            "trinity": [seat.to_dict() for seat in self.trinity],
        }


def default_registry() -> SeatRegistry:
    provider_models = (
        ("openai", "env:OPENAI_MODEL"),
        ("anthropic", "env:ANTHROPIC_MODEL"),
        ("gemini", "env:GEMINI_MODEL"),
        ("xai", "env:XAI_MODEL"),
        ("groq", "env:GROQ_MODEL"),
        ("openrouter", "env:OPENROUTER_MODEL"),
        ("ollama", "env:OLLAMA_MODEL"),
        ("oauth_bridge", "env:OAUTH_BRIDGE_MODEL"),
    )
    seats = []
    for index in range(40):
        role = ROLE_FAMILIES[index % len(ROLE_FAMILIES)]
        provider, model = provider_models[index % len(provider_models)]
        seats.append(
            SeatConfig(
                id=f"seat_{index + 1:02d}",
                provider=provider,
                model=model,
                role=role,
                domains=(role, "general"),
            )
        )
    return SeatRegistry(
        seats=tuple(seats),
        trinity=(
            SeatConfig("trinity_gpt", "openai", "env:OPENAI_TRINITY_MODEL", "pattern_execution_synthesis", ("synthesis",)),
            SeatConfig("trinity_claude", "anthropic", "env:ANTHROPIC_TRINITY_MODEL", "critique_recursive_integration", ("synthesis",)),
            SeatConfig("trinity_gemini", "gemini", "env:GEMINI_TRINITY_MODEL", "hypothesis_expansion", ("synthesis",)),
        ),
        planner=SeatConfig("planner", "openai", "env:OPENAI_PLANNER_MODEL", "planner", ("planning",)),
    )


def host_session_registry() -> SeatRegistry:
    """Forty-seat layout backed by authenticated host CLIs instead of API keys."""

    provider_models = (
        ("codex_session", "session-default"),
        ("claude_session", "sonnet"),
        ("gemini_session", "session-default"),
    )
    seats = []
    for index in range(40):
        role = ROLE_FAMILIES[index % len(ROLE_FAMILIES)]
        provider, model = provider_models[index % len(provider_models)]
        seats.append(
            SeatConfig(
                id=f"seat_{index + 1:02d}",
                provider=provider,
                model=model,
                role=role,
                domains=(role, "general"),
            )
        )
    return SeatRegistry(
        seats=tuple(seats),
        trinity=(
            SeatConfig(
                "trinity_gpt",
                "codex_session",
                "session-default",
                "pattern_execution_synthesis",
                ("synthesis",),
            ),
            SeatConfig(
                "trinity_claude",
                "claude_session",
                "sonnet",
                "critique_recursive_integration",
                ("synthesis",),
            ),
            SeatConfig(
                "trinity_gemini",
                "gemini_session",
                "session-default",
                "hypothesis_expansion",
                ("synthesis",),
            ),
        ),
        planner=SeatConfig(
            "planner",
            "codex_session",
            "session-default",
            "planner",
            ("planning",),
        ),
    )


def anvil_ollama_registry() -> SeatRegistry:
    """Forty-seat local-inference layout for ANVIL's verified Ollama models."""

    models = (
        "qwen2.5-coder:3b",
        "qwen2.5:3b-instruct",
        "qwen2.5:1.5b-instruct",
    )
    seats = []
    for index in range(40):
        role = ROLE_FAMILIES[index % len(ROLE_FAMILIES)]
        model = models[index % len(models)]
        seats.append(
            SeatConfig(
                id=f"seat_{index + 1:02d}",
                provider="anvil_ollama",
                model=model,
                role=role,
                domains=(role, "general", "local_inference"),
            )
        )
    return SeatRegistry(
        seats=tuple(seats),
        trinity=(
            SeatConfig(
                "trinity_gpt",
                "anvil_ollama",
                models[0],
                "pattern_execution_synthesis",
                ("synthesis", "local_inference"),
            ),
            SeatConfig(
                "trinity_claude",
                "anvil_ollama",
                models[1],
                "critique_recursive_integration",
                ("synthesis", "local_inference"),
            ),
            SeatConfig(
                "trinity_gemini",
                "anvil_ollama",
                models[2],
                "hypothesis_expansion",
                ("synthesis", "local_inference"),
            ),
        ),
        planner=SeatConfig(
            "planner",
            "anvil_ollama",
            models[0],
            "planner",
            ("planning", "local_inference"),
        ),
    )
