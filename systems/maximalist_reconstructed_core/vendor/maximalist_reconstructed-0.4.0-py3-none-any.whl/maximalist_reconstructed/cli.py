from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import uuid
from pathlib import Path
from typing import Any

from .capabilities import (
    CapabilityCatalog,
    CapabilityOrchestrator,
    EchoSDKCapabilityAdapter,
    build_deterministic_capability_orchestrator,
    build_live_capability_orchestrator,
    load_capability_adapter_factory,
)
from .config import SeatRegistry, anvil_ollama_registry, default_registry, host_session_registry
from .control import (
    BudgetExceeded,
    BudgetPolicy,
    CostTable,
    DeadlineExceeded,
    RunCancelled,
    RunControlError,
    UncertainCallError,
)
from .fusion import FusionEngine, RunPaused
from .memory import JsonFileMemoryAdapter
from .preflight import PreflightReport, build_preflight_report, select_canary_seats
from .providers import (
    AnvilOllamaAdapter,
    ProviderRegistry,
    build_deterministic_registry,
    build_live_registry,
    load_provider_adapter_factory,
)
from .session_providers import build_session_adapter
from .state import JsonRunStateStore


PROFILE_NAME = "MAXIMALIST_RECONSTRUCTED"


def _default_config_path() -> Path | None:
    candidate = Path(__file__).resolve().parents[2] / "config" / "seats.json"
    return candidate if candidate.exists() else None


def _load_registry(
    path: str | None,
    *,
    session_layout: bool = False,
    anvil_layout: bool = False,
) -> SeatRegistry:
    selected_layouts = int(bool(path)) + int(session_layout) + int(anvil_layout)
    if selected_layouts > 1:
        raise ValueError("use only one of --config, --session-layout, or --anvil-layout")
    if path:
        return SeatRegistry.load(path)
    if session_layout:
        return host_session_registry()
    if anvil_layout:
        return anvil_ollama_registry()
    default_path = _default_config_path()
    return SeatRegistry.load(default_path) if default_path else default_registry()


def _provider_names(registry: SeatRegistry) -> set[str]:
    return {seat.provider for seat in (*registry.seats, *registry.trinity, registry.planner)}


def _parse_provider_limits(values: list[str] | None) -> dict[str, int]:
    parsed: dict[str, int] = {}
    for value in values or []:
        provider, separator, raw_limit = value.partition("=")
        if not separator or not provider.strip():
            raise ValueError("--provider-limit must use PROVIDER=COUNT syntax")
        try:
            limit = int(raw_limit)
        except ValueError as exc:
            raise ValueError("--provider-limit COUNT must be an integer") from exc
        if limit <= 0:
            raise ValueError("--provider-limit COUNT must be positive")
        parsed[provider.strip().lower()] = limit
    return parsed


def _budget_policy(args: argparse.Namespace) -> BudgetPolicy:
    deterministic = args.runtime == "fake"
    return BudgetPolicy(
        max_calls=args.max_calls if args.max_calls is not None else (100 if deterministic else 24),
        max_input_tokens=(
            args.max_input_tokens if args.max_input_tokens is not None else (250_000 if deterministic else 60_000)
        ),
        max_output_tokens=(
            args.max_output_tokens if args.max_output_tokens is not None else (100_000 if deterministic else 16_000)
        ),
        max_estimated_cost_usd=(
            args.max_cost_usd if args.max_cost_usd is not None else (0.0 if deterministic else 1.0)
        ),
        max_output_tokens_per_call=args.max_output_per_call,
        deadline_seconds=args.deadline_seconds,
        request_timeout_seconds=args.request_timeout_seconds,
        retry_limit=args.retry_limit,
        retry_backoff_seconds=args.retry_backoff_seconds,
        circuit_failure_threshold=args.circuit_failure_threshold,
        circuit_cooldown_seconds=args.circuit_cooldown_seconds,
        default_provider_concurrency=args.provider_concurrency,
        provider_concurrency=_parse_provider_limits(args.provider_limit),
        require_pricing=not deterministic,
    )


def _runtime_components(
    args: argparse.Namespace,
    registry: SeatRegistry,
) -> tuple[ProviderRegistry, str, CostTable]:
    if args.runtime == "fake":
        if args.session_provider:
            raise ValueError("--session-provider is available only with --runtime live")
        providers, _ = build_deterministic_registry(_provider_names(registry))
        return providers, "deterministic_test", CostTable(free_providers=_provider_names(registry))
    oauth_bridge = (
        load_provider_adapter_factory(args.oauth_bridge_factory)
        if args.oauth_bridge_factory
        else None
    )
    providers = build_live_registry(oauth_bridge=oauth_bridge)
    costs = CostTable.load(args.pricing) if args.pricing else CostTable(free_providers={"ollama"})
    session_working_directory = Path(args.state_dir) / "session-runtime"
    for name in list(dict.fromkeys(args.session_provider or [])):
        provider_name = f"{name}_session"
        providers.register(provider_name, build_session_adapter(name, session_working_directory))
        costs.free_providers.add(provider_name)
    if "anvil_ollama" in _provider_names(registry) or args.anvil_base_url:
        providers.register(
            "anvil_ollama",
            AnvilOllamaAdapter(
                base_url=(
                    args.anvil_base_url
                    or os.environ.get("ANVIL_OLLAMA_BASE_URL", "").strip()
                    or "http://anvil-1.tail07cfd0.ts.net:11434/api"
                )
            ),
        )
        costs.free_providers.add("anvil_ollama")
    return providers, "live", costs


def _capability_components(
    args: argparse.Namespace,
    *,
    resume_capability_ids: list[str] | None = None,
) -> CapabilityOrchestrator:
    catalog = CapabilityCatalog.load(args.capability_config)
    profile = args.capability_profile or "off"
    explicit_ids = list(dict.fromkeys(args.capability_id or resume_capability_ids or []))
    if args.runtime == "fake":
        orchestrator, _ = build_deterministic_capability_orchestrator(
            catalog,
            profile,
            explicit_ids=explicit_ids,
            max_calls=args.max_capability_calls,
        )
        return orchestrator
    adapter = (
        load_capability_adapter_factory(args.capability_adapter_factory)
        if args.capability_adapter_factory
        else EchoSDKCapabilityAdapter(
            args.sdk_base_url
            or os.environ.get("MAXIMALIST_SDK_BASE_URL", "").strip()
            or os.environ.get("ECHO_SDK_BASE_URL", "").strip()
            or "http://127.0.0.1:8000",
            api_key_env=args.sdk_api_key_env,
        )
    )
    return build_live_capability_orchestrator(
        catalog,
        profile,
        adapter=adapter,
        explicit_ids=explicit_ids,
        max_calls=args.max_capability_calls,
    )


def _build_engine(
    args: argparse.Namespace,
    registry: SeatRegistry,
    providers: ProviderRegistry,
    provider_mode: str,
    costs: CostTable,
    capabilities: CapabilityOrchestrator,
) -> FusionEngine:
    state_dir = Path(args.state_dir)
    return FusionEngine(
        providers=providers,
        memory=JsonFileMemoryAdapter(args.memory_file or state_dir / "memory.json"),
        registry=registry,
        state_store=JsonRunStateStore(state_dir),
        max_fusion_passes=args.max_fusion_passes,
        convergence_threshold=args.convergence_threshold,
        max_concurrency=args.max_concurrency,
        provider_mode=provider_mode,
        budget_policy=_budget_policy(args),
        cost_table=costs,
        capabilities=capabilities,
    )


def _context(value: str | None) -> dict[str, Any]:
    if not value:
        return {}
    decoded = json.loads(value)
    if not isinstance(decoded, dict):
        raise ValueError("--context-json must decode to an object")
    return decoded


def _emit(payload: dict[str, Any], *, pretty: bool, output: str | None) -> None:
    rendered = json.dumps(payload, indent=2 if pretty else None, sort_keys=True)
    if output:
        path = Path(output)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)


def _validate_live_selection(
    args: argparse.Namespace,
    report: PreflightReport,
    registry: SeatRegistry,
) -> list[str] | None:
    explicit = list(dict.fromkeys(args.seat_id or []))
    if explicit and args.canary_seats is not None:
        raise ValueError("use either --seat-id or --canary-seats, not both")
    if not report.planner_ready:
        raise ValueError("live execution blocked: the configured planner is not ready")
    if not report.ready_trinity_seats:
        raise ValueError("live execution blocked: no Trinity seat is ready")
    if explicit:
        unknown = sorted(set(explicit) - {seat.id for seat in registry.enabled_seats})
        if unknown:
            raise ValueError(f"selected seat identifiers are not configured: {unknown}")
        unready = sorted(set(explicit) - set(report.ready_swarm_seats))
        if unready:
            raise ValueError(f"live execution blocked: selected seats are not ready: {unready}")
        return explicit
    if args.canary_seats is not None:
        if not report.can_run_live_canary:
            raise ValueError("live canary blocked by provider readiness")
        selected = select_canary_seats(report, registry, args.canary_seats)
        if len(selected) != args.canary_seats:
            raise ValueError(
                f"live canary requested {args.canary_seats} seats but only {len(selected)} are ready"
            )
        return selected
    if not args.full_live:
        raise ValueError(
            "live execution requires --canary-seats N, one or more --seat-id values, or explicit --full-live"
        )
    return None


def _blocked_payload(exc: RunControlError, run_id: str, engine: FusionEngine) -> dict[str, Any]:
    statuses = {
        RunCancelled: "cancelled",
        BudgetExceeded: "blocked_budget",
        DeadlineExceeded: "blocked_deadline",
        UncertainCallError: "blocked_uncertain",
    }
    status = next((value for kind, value in statuses.items() if isinstance(exc, kind)), "blocked")
    payload: dict[str, Any] = {
        "status": status,
        "run_id": run_id,
        "blocker": f"{type(exc).__name__}: {exc}",
        "profile": PROFILE_NAME,
        "historical_parity": False,
    }
    if engine.state_store.exists(run_id):
        state = engine.state_store.load(run_id)
        payload.update(
            {
                "phase": state.last_completed_phase,
                "checkpoint": str(engine.state_store.path_for(run_id)),
                "execution_ledger": {
                    "calls_started": state.execution_ledger.calls_started,
                    "calls_completed": state.execution_ledger.calls_completed,
                    "calls_failed": state.execution_ledger.calls_failed,
                    "input_tokens_observed": state.execution_ledger.input_tokens_observed,
                    "output_tokens_observed": state.execution_ledger.output_tokens_observed,
                    "estimated_cost_usd_reserved": state.execution_ledger.estimated_cost_usd_reserved,
                    "budget_exceeded_reason": state.execution_ledger.budget_exceeded_reason,
                    "uncertain_call_ids": [item.call_id for item in state.execution_ledger.uncertain_calls],
                },
            }
        )
    return payload


async def _run_async(args: argparse.Namespace) -> int:
    if args.command == "cancel":
        store = JsonRunStateStore(args.state_dir)
        state = store.request_cancel(args.run_id, args.reason)
        _emit(
            {
                "status": state.status,
                "run_id": state.run_id,
                "reason": state.cancel_reason,
                "checkpoint": str(store.path_for(state.run_id)),
                "profile": PROFILE_NAME,
                "historical_parity": False,
            },
            pretty=args.pretty,
            output=args.output,
        )
        return 0

    if args.runtime is None:
        raise ValueError("--runtime fake|live is required for preflight, run, and resume")
    resume_capability_ids: list[str] | None = None
    if args.command == "resume":
        checkpoint = JsonRunStateStore(args.state_dir).load(args.run_id)
        if args.capability_profile is None:
            args.capability_profile = checkpoint.capability_profile
        if not args.capability_id:
            resume_capability_ids = checkpoint.selected_capability_ids
    else:
        args.capability_profile = args.capability_profile or "off"
    registry = _load_registry(
        args.config,
        session_layout=args.session_layout,
        anvil_layout=args.anvil_layout,
    )
    providers, provider_mode, costs = _runtime_components(args, registry)
    capabilities = _capability_components(
        args,
        resume_capability_ids=resume_capability_ids,
    )
    report = await build_preflight_report(registry, providers, costs, runtime=args.runtime)
    capability_report = await capabilities.preflight()
    if args.command == "preflight":
        _emit(
            {
                "status": "ready" if report.can_run_live_canary or args.runtime == "fake" else "blocked",
                "profile": PROFILE_NAME,
                "historical_parity": False,
                "preflight": report.to_dict(),
                "capability_preflight": capability_report,
            },
            pretty=args.pretty,
            output=args.output,
        )
        return 0

    engine = _build_engine(args, registry, providers, provider_mode, costs, capabilities)
    run_id = args.run_id if args.command == "resume" else uuid.uuid4().hex
    try:
        if args.command == "run":
            if args.runtime == "live":
                selected = _validate_live_selection(args, report, registry)
            else:
                if args.seat_id and args.canary_seats is not None:
                    raise ValueError("use either --seat-id or --canary-seats, not both")
                selected = list(dict.fromkeys(args.seat_id or [])) or None
                if args.canary_seats is not None:
                    selected = select_canary_seats(report, registry, args.canary_seats)
                    if len(selected) != args.canary_seats:
                        raise ValueError(
                            f"deterministic canary requested {args.canary_seats} seats but only {len(selected)} are configured"
                        )
            execution_mode = (
                "live_canary"
                if args.runtime == "live" and selected is not None
                else "full_live"
                if args.runtime == "live"
                else "deterministic_canary"
                if selected is not None
                else "deterministic_test"
            )
            result = await engine.run(
                args.objective,
                _context(args.context_json),
                run_id=run_id,
                pause_after=args.pause_after,
                selected_seat_ids=selected,
                selected_trinity_ids=(report.ready_trinity_seats if args.runtime == "live" else None),
                execution_mode=execution_mode,
            )
        else:
            state = engine.state_store.load(run_id)
            is_deterministic = state.execution_mode.startswith("deterministic")
            if is_deterministic != (args.runtime == "fake"):
                raise ValueError("resume runtime does not match the checkpoint execution mode")
            result = await engine.resume(run_id, pause_after=args.pause_after)
    except RunPaused as paused:
        state = engine.state_store.load(paused.run_id)
        _emit(
            {
                "status": "paused",
                "run_id": paused.run_id,
                "phase": paused.phase,
                "checkpoint": str(engine.state_store.path_for(paused.run_id)),
                "profile": PROFILE_NAME,
                "historical_parity": False,
                "provider_mode": engine.provider_mode,
                "execution_ledger": state.execution_ledger.to_dict(),
                "capability_profile": state.capability_profile,
                "capability_mode": state.capability_mode,
                "capability_results": [item.to_dict() for item in state.capability_results],
            },
            pretty=args.pretty,
            output=args.output,
        )
        return 0
    except RunControlError as exc:
        _emit(
            _blocked_payload(exc, run_id, engine),
            pretty=args.pretty,
            output=args.output,
        )
        return 2
    _emit({"status": "completed", "result": result.to_dict()}, pretty=args.pretty, output=args.output)
    return 0


def _add_pause_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--pause-after",
        choices=(
            "memory_retrieved",
            "capabilities_grounded",
            "decomposed",
            "independent_pass",
            "findings_published",
            "retasked",
            "critiqued",
            "arbitrated",
            "fusion_pass",
            "finalized",
        ),
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="maximalist-reconstructed",
        description="Run the standalone MAXIMALIST_RECONSTRUCTED Fusion Brain.",
    )
    parser.add_argument("--config", help="40-seat JSON configuration; defaults to config/seats.json")
    parser.add_argument(
        "--session-layout",
        action="store_true",
        help="use the built-in 40-seat Codex/Claude/Gemini host-session layout",
    )
    parser.add_argument(
        "--anvil-layout",
        action="store_true",
        help="use the built-in 40-seat ANVIL Ollama layout with three verified Qwen models",
    )
    parser.add_argument(
        "--anvil-base-url",
        help="ANVIL Ollama base URL; defaults to ANVIL_OLLAMA_BASE_URL or private Tailnet DNS",
    )
    parser.add_argument("--state-dir", default=".run-state", help="atomic checkpoint directory")
    parser.add_argument("--memory-file", help="JSON memory path; defaults inside state-dir")
    parser.add_argument(
        "--capability-config",
        help="read-only capability catalog JSON; defaults to the package catalog",
    )
    parser.add_argument(
        "--capability-profile",
        help="capability profile such as off, knowledge, or echo_full_read",
    )
    parser.add_argument(
        "--capability-id",
        action="append",
        help="add one explicitly cataloged read-only SDK capability; repeatable",
    )
    parser.add_argument(
        "--capability-adapter-factory",
        help="MODULE:CALLABLE returning an already-authorized capability adapter",
    )
    parser.add_argument(
        "--sdk-base-url",
        help="Echo SDK base URL for live capability grounding",
    )
    parser.add_argument(
        "--sdk-api-key-env",
        default="ECHO_SDK_API_KEY",
        help="environment variable name containing the SDK key; the value is never serialized",
    )
    parser.add_argument("--max-capability-calls", type=int, default=12)
    parser.add_argument(
        "--runtime",
        choices=("fake", "live"),
        help="fake is deterministic test-only; live uses credentialed or host-session provider adapters",
    )
    parser.add_argument("--pricing", help="verified provider-pricing JSON; required for paid live models")
    parser.add_argument(
        "--oauth-bridge-factory",
        help="zero-argument MODULE:CALLABLE returning an already-authorized provider adapter",
    )
    parser.add_argument(
        "--session-provider",
        action="append",
        choices=("codex", "claude", "gemini"),
        help="register an authenticated host CLI provider; repeatable",
    )
    parser.add_argument("--max-calls", type=int)
    parser.add_argument("--max-input-tokens", type=int)
    parser.add_argument("--max-output-tokens", type=int)
    parser.add_argument("--max-cost-usd", type=float)
    parser.add_argument("--max-output-per-call", type=int, default=512)
    parser.add_argument("--deadline-seconds", type=float, default=300.0)
    parser.add_argument("--request-timeout-seconds", type=float, default=60.0)
    parser.add_argument("--retry-limit", type=int, default=1)
    parser.add_argument("--retry-backoff-seconds", type=float, default=0.25)
    parser.add_argument("--circuit-failure-threshold", type=int, default=2)
    parser.add_argument("--circuit-cooldown-seconds", type=float, default=60.0)
    parser.add_argument("--provider-concurrency", type=int, default=2)
    parser.add_argument(
        "--provider-limit",
        action="append",
        help="per-provider concurrency override in PROVIDER=COUNT form; repeatable",
    )
    parser.add_argument("--max-fusion-passes", type=int, default=3)
    parser.add_argument("--convergence-threshold", type=float, default=0.88)
    parser.add_argument("--max-concurrency", type=int, default=10)
    parser.add_argument("--pretty", action="store_true")
    parser.add_argument("--output", help="also write the emitted JSON to this path")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("preflight", help="report redacted provider, model, and budget readiness")

    run_parser = subparsers.add_parser("run", help="start a new run")
    run_parser.add_argument("objective")
    run_parser.add_argument("--context-json")
    run_parser.add_argument("--canary-seats", type=int)
    run_parser.add_argument("--seat-id", action="append", help="select an explicit swarm seat; repeatable")
    run_parser.add_argument("--full-live", action="store_true", help="explicitly authorize all configured live seats")
    _add_pause_argument(run_parser)

    resume_parser = subparsers.add_parser("resume", help="resume a checkpointed run")
    resume_parser.add_argument("run_id")
    _add_pause_argument(resume_parser)

    cancel_parser = subparsers.add_parser("cancel", help="persist an operator cancellation request")
    cancel_parser.add_argument("run_id")
    cancel_parser.add_argument("--reason")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return asyncio.run(_run_async(args))
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        parser.error(str(exc))
    except KeyboardInterrupt:
        return 130
    return 1


if __name__ == "__main__":
    sys.exit(main())
