from __future__ import annotations

import asyncio
import importlib
import json
import os
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, ClassVar, Protocol


class ProviderError(RuntimeError):
    """A bounded provider failure that the registry may route around."""

    def __init__(self, message: str, *, retryable: bool = False, status_code: int | None = None) -> None:
        super().__init__(message)
        self.retryable = retryable
        self.status_code = status_code


@dataclass(slots=True)
class ProviderRequest:
    provider: str
    seat_id: str
    model: str
    role: str
    prompt: str
    context: dict[str, Any]
    phase: str
    max_output_tokens: int = 2048


@dataclass(slots=True)
class ProviderCompletion:
    """Provider text plus optional authoritative usage counters."""

    text: str
    input_tokens: int | None = None
    cached_input_tokens: int | None = None
    output_tokens: int | None = None
    usage_source: str = "provider_reported"

    def __post_init__(self) -> None:
        if not isinstance(self.text, str):
            raise TypeError("provider completion text must be a string")
        for name in ("input_tokens", "cached_input_tokens", "output_tokens"):
            value = getattr(self, name)
            if value is not None and value < 0:
                raise ValueError(f"{name} must not be negative")


class ProviderAdapter(Protocol):
    async def complete(self, request: ProviderRequest) -> str | ProviderCompletion:
        ...


def resolve_model_reference(model: str, *, resolve_environment: bool) -> str:
    if not model.startswith("env:"):
        return model
    if not resolve_environment:
        return model
    variable = model.removeprefix("env:").strip()
    value = os.environ.get(variable, "").strip()
    if not value:
        raise ProviderError(f"required model environment variable is not set: {variable}")
    return value


class ProviderRegistry:
    def __init__(self, *, fallback_provider: str | None = None, resolve_environment_models: bool = True) -> None:
        self._adapters: dict[str, ProviderAdapter] = {}
        self.fallback_provider = fallback_provider
        self.resolve_environment_models = resolve_environment_models
        self.failures: list[dict[str, str]] = []

    def register(self, name: str, adapter: ProviderAdapter) -> None:
        normalized = name.strip().lower()
        if not normalized:
            raise ValueError("provider name must not be empty")
        self._adapters[normalized] = adapter

    @property
    def registered_names(self) -> set[str]:
        return set(self._adapters)

    def adapter_for(self, name: str) -> ProviderAdapter | None:
        return self._adapters.get(name.strip().lower())

    def prepare(self, request: ProviderRequest, *, provider: str | None = None) -> tuple[ProviderAdapter, ProviderRequest]:
        requested = (provider or request.provider).strip().lower()
        adapter = self._adapters.get(requested)
        if adapter is None:
            raise ProviderError(f"provider is not registered: {requested}")
        resolved = ProviderRequest(
            provider=requested,
            seat_id=request.seat_id,
            model=resolve_model_reference(request.model, resolve_environment=self.resolve_environment_models),
            role=request.role,
            prompt=request.prompt,
            context=request.context,
            phase=request.phase,
            max_output_tokens=request.max_output_tokens,
        )
        return adapter, resolved

    @staticmethod
    async def invoke(
        adapter: ProviderAdapter,
        request: ProviderRequest,
    ) -> str | ProviderCompletion:
        return await adapter.complete(request)

    async def complete(self, request: ProviderRequest) -> str | ProviderCompletion:
        adapter, resolved = self.prepare(request)
        requested = resolved.provider
        try:
            return await self.invoke(adapter, resolved)
        except Exception as exc:
            self.failures.append({"provider": requested, "seat_id": request.seat_id, "phase": request.phase, "error": str(exc)})
            fallback_name = (self.fallback_provider or "").lower()
            fallback = self._adapters.get(fallback_name)
            if fallback is None or fallback_name == requested:
                if isinstance(exc, ProviderError):
                    raise
                raise ProviderError(f"{requested} failed: {exc}") from exc
            fallback_request = ProviderRequest(
                provider=fallback_name,
                seat_id=request.seat_id,
                model=resolved.model,
                role=request.role,
                prompt=request.prompt,
                context={**request.context, "fallback_from": requested},
                phase=request.phase,
                max_output_tokens=request.max_output_tokens,
            )
            return await fallback.complete(fallback_request)


@dataclass(slots=True)
class CallableProviderAdapter:
    """Bridge for OAuth/session-authenticated host providers without exposing credentials."""

    callback: Callable[[ProviderRequest], str | Awaitable[str]]
    readiness_callback: Callable[[str], bool | Awaitable[bool]] | None = None

    async def complete(self, request: ProviderRequest) -> str:
        value = self.callback(request)
        if isinstance(value, str):
            return value
        return await value

    async def probe(self, model: str) -> bool:
        if self.readiness_callback is None:
            return True
        value = self.readiness_callback(model)
        if isinstance(value, bool):
            return value
        return bool(await value)


@dataclass(slots=True)
class HTTPJSONTransport:
    timeout_seconds: float = 60.0
    max_response_bytes: int = 4 * 1024 * 1024

    async def post(self, url: str, payload: dict[str, Any], headers: dict[str, str]) -> dict[str, Any]:
        return await asyncio.to_thread(self._post_sync, url, payload, headers)

    async def get(self, url: str, headers: dict[str, str]) -> dict[str, Any]:
        return await asyncio.to_thread(self._get_sync, url, headers)

    def _decode_response(self, raw: bytes) -> dict[str, Any]:
        if len(raw) > self.max_response_bytes:
            raise ProviderError("provider response exceeded configured byte limit")
        try:
            value = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ProviderError("provider returned invalid JSON") from exc
        if not isinstance(value, dict):
            raise ProviderError("provider returned a non-object JSON response")
        return value

    def _get_sync(self, url: str, headers: dict[str, str]) -> dict[str, Any]:
        request = urllib.request.Request(url, headers=headers, method="GET")
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                raw = response.read(self.max_response_bytes + 1)
        except urllib.error.HTTPError as exc:
            raise ProviderError(
                f"HTTP {exc.code}: provider readiness request failed",
                retryable=exc.code == 429 or 500 <= exc.code < 600,
                status_code=exc.code,
            ) from exc
        except urllib.error.URLError as exc:
            raise ProviderError("provider readiness connection failed", retryable=True) from exc
        return self._decode_response(raw)

    def _post_sync(self, url: str, payload: dict[str, Any], headers: dict[str, str]) -> dict[str, Any]:
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        request = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": "application/json", **headers},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                raw = response.read(self.max_response_bytes + 1)
        except urllib.error.HTTPError as exc:
            raise ProviderError(
                f"HTTP {exc.code}: provider request failed",
                retryable=exc.code == 429 or 500 <= exc.code < 600,
                status_code=exc.code,
            ) from exc
        except urllib.error.URLError as exc:
            raise ProviderError("provider connection failed", retryable=True) from exc
        return self._decode_response(raw)


def _required_secret(variable: str) -> str:
    value = os.environ.get(variable, "").strip()
    if not value:
        raise ProviderError(f"required credential environment variable is not set: {variable}")
    return value


@dataclass(slots=True)
class OpenAIResponsesAdapter:
    base_url: str = "https://api.openai.com/v1"
    api_key_env: str = "OPENAI_API_KEY"
    transport: HTTPJSONTransport = field(default_factory=HTTPJSONTransport)

    async def complete(self, request: ProviderRequest) -> str:
        response = await self.transport.post(
            f"{self.base_url.rstrip('/')}/responses",
            {"model": request.model, "input": request.prompt, "max_output_tokens": request.max_output_tokens},
            {"Authorization": f"Bearer {_required_secret(self.api_key_env)}"},
        )
        if isinstance(response.get("output_text"), str):
            return response["output_text"]
        texts: list[str] = []
        for output in response.get("output", []):
            if not isinstance(output, dict):
                continue
            for content in output.get("content", []):
                if isinstance(content, dict) and isinstance(content.get("text"), str):
                    texts.append(content["text"])
        if not texts:
            raise ProviderError("Responses API returned no output text")
        return "\n".join(texts)


@dataclass(slots=True)
class OpenAICompatibleChatAdapter:
    base_url: str
    api_key_env: str
    transport: HTTPJSONTransport = field(default_factory=HTTPJSONTransport)

    async def complete(self, request: ProviderRequest) -> str:
        response = await self.transport.post(
            f"{self.base_url.rstrip('/')}/chat/completions",
            {
                "model": request.model,
                "messages": [{"role": "user", "content": request.prompt}],
                "max_completion_tokens": request.max_output_tokens,
            },
            {"Authorization": f"Bearer {_required_secret(self.api_key_env)}"},
        )
        try:
            text = response["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError("chat-completions provider returned no message text") from exc
        if not isinstance(text, str):
            raise ProviderError("chat-completions message content was not text")
        return text


@dataclass(slots=True)
class AnthropicMessagesAdapter:
    base_url: str = "https://api.anthropic.com/v1"
    api_key_env: str = "ANTHROPIC_API_KEY"
    api_version: str = "2023-06-01"
    transport: HTTPJSONTransport = field(default_factory=HTTPJSONTransport)

    async def complete(self, request: ProviderRequest) -> str:
        response = await self.transport.post(
            f"{self.base_url.rstrip('/')}/messages",
            {
                "model": request.model,
                "max_tokens": request.max_output_tokens,
                "messages": [{"role": "user", "content": request.prompt}],
            },
            {"x-api-key": _required_secret(self.api_key_env), "anthropic-version": self.api_version},
        )
        texts = [
            item["text"]
            for item in response.get("content", [])
            if isinstance(item, dict) and item.get("type") == "text" and isinstance(item.get("text"), str)
        ]
        if not texts:
            raise ProviderError("Anthropic Messages API returned no text content")
        return "\n".join(texts)


@dataclass(slots=True)
class GeminiGenerateContentAdapter:
    base_url: str = "https://generativelanguage.googleapis.com/v1beta"
    api_key_env: str = "GEMINI_API_KEY"
    transport: HTTPJSONTransport = field(default_factory=HTTPJSONTransport)

    async def complete(self, request: ProviderRequest) -> str:
        model = urllib.parse.quote(request.model, safe="-_.")
        response = await self.transport.post(
            f"{self.base_url.rstrip('/')}/models/{model}:generateContent",
            {
                "contents": [{"role": "user", "parts": [{"text": request.prompt}]}],
                "generationConfig": {"maxOutputTokens": request.max_output_tokens},
            },
            {"x-goog-api-key": _required_secret(self.api_key_env)},
        )
        texts: list[str] = []
        for candidate in response.get("candidates", []):
            if not isinstance(candidate, dict):
                continue
            content = candidate.get("content", {})
            for part in content.get("parts", []) if isinstance(content, dict) else []:
                if isinstance(part, dict) and isinstance(part.get("text"), str):
                    texts.append(part["text"])
        if not texts:
            raise ProviderError("Gemini generateContent returned no text")
        return "\n".join(texts)


@dataclass(slots=True)
class OllamaGenerateAdapter:
    base_url: str = "http://127.0.0.1:11434/api"
    allow_remote: bool = False
    transport: HTTPJSONTransport = field(default_factory=HTTPJSONTransport)

    def __post_init__(self) -> None:
        host = urllib.parse.urlparse(self.base_url).hostname
        if not self.allow_remote and host not in {"127.0.0.1", "localhost", "::1"}:
            raise ValueError("Ollama base URL must be loopback unless allow_remote is explicitly enabled")

    async def complete(self, request: ProviderRequest) -> str:
        response = await self.transport.post(
            f"{self.base_url.rstrip('/')}/generate",
            {
                "model": request.model,
                "prompt": request.prompt,
                "stream": False,
                "format": "json",
                "options": {"num_predict": request.max_output_tokens},
            },
            {},
        )
        text = response.get("response")
        if not isinstance(text, str):
            raise ProviderError("Ollama generate returned no response text")
        return text

    async def probe(self, model: str) -> bool:
        response = await self.transport.get(f"{self.base_url.rstrip('/')}/tags", {})
        names = {
            str(item.get("name", ""))
            for item in response.get("models", [])
            if isinstance(item, dict)
        }
        return model in names or any(name.split(":", 1)[0] == model for name in names)


ANVIL_OLLAMA_DEFAULT_BASE_URL = "http://anvil-1.tail07cfd0.ts.net:11434/api"


@dataclass(slots=True)
class AnvilOllamaAdapter:
    """Zero-key Ollama adapter for the ANVIL node's private Tailnet endpoint.

    The endpoint can be overridden without embedding credentials.  Network and
    model readiness are always established through ``/api/tags`` before a live
    seat is selected.
    """

    base_url: str = field(
        default_factory=lambda: os.environ.get(
            "ANVIL_OLLAMA_BASE_URL", ANVIL_OLLAMA_DEFAULT_BASE_URL
        ).strip()
        or ANVIL_OLLAMA_DEFAULT_BASE_URL
    )
    transport: HTTPJSONTransport = field(default_factory=HTTPJSONTransport)

    probe_verifies_network: ClassVar[bool] = True
    auth_mode: ClassVar[str] = "private_tailnet_zero_key"
    metering: ClassVar[str] = "local_zero_cost"
    node_name: ClassVar[str] = "ANVIL"

    def __post_init__(self) -> None:
        parsed = urllib.parse.urlparse(self.base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            raise ValueError("ANVIL Ollama base URL must be an absolute HTTP(S) URL")
        path = parsed.path.rstrip("/")
        if path in {"", "/"}:
            self.base_url = self.base_url.rstrip("/") + "/api"
        elif path != "/api":
            raise ValueError("ANVIL Ollama base URL path must be /api or empty")

    async def complete(self, request: ProviderRequest) -> ProviderCompletion:
        response = await self.transport.post(
            f"{self.base_url.rstrip('/')}/generate",
            {
                "model": request.model,
                "prompt": request.prompt,
                "stream": False,
                "format": "json",
                "options": {"num_predict": request.max_output_tokens},
            },
            {},
        )
        text = response.get("response")
        if not isinstance(text, str):
            raise ProviderError("ANVIL Ollama generate returned no response text")

        def count(name: str) -> int | None:
            value = response.get(name)
            return int(value) if isinstance(value, (int, float)) and value >= 0 else None

        return ProviderCompletion(
            text=text,
            input_tokens=count("prompt_eval_count"),
            output_tokens=count("eval_count"),
            usage_source="ollama_native",
        )

    async def probe(self, model: str) -> bool:
        delegate = OllamaGenerateAdapter(
            base_url=self.base_url,
            allow_remote=True,
            transport=self.transport,
        )
        return await delegate.probe(model)


@dataclass(slots=True)
class DeterministicFakeProvider:
    """Deterministic test double. Never represents a real model response."""

    calls: list[ProviderRequest] = field(default_factory=list)
    first_fusion_confidence: float = 0.62

    async def complete(self, request: ProviderRequest) -> str:
        self.calls.append(request)
        phase = request.phase
        if phase == "decompose":
            return "requirements\nrisks\nevidence\nintegration"
        if phase == "trinity":
            fusion_pass = int(request.context.get("fusion_pass", 1))
            confidence = self.first_fusion_confidence if fusion_pass == 1 else 0.93
            weak = ["resilience conclusion"] if fusion_pass == 1 else []
            top = request.context.get("ranked_findings", [])
            claims = [item.get("finding", {}).get("claim", "") for item in top[:3] if isinstance(item, dict)]
            return json.dumps(
                {
                    "answer": f"Deterministic test synthesis pass {fusion_pass}: " + "; ".join(filter(None, claims)),
                    "confidence": confidence,
                    "supported_claims": claims,
                    "weak_claims": weak,
                    "unresolved": weak,
                },
                sort_keys=True,
            )
        if phase in {"retask", "critique", "verify"}:
            visible = request.context.get("visible_findings", [])
            inspected = visible[0] if visible else {}
            topic = str(inspected.get("topic", "resilience"))
            stance = str(inspected.get("stance", "supports"))
            return json.dumps(
                {
                    "analysis": f"deterministic {phase}",
                    "findings": [
                        {
                            "claim": f"{phase} confirms {topic}",
                            "topic": topic,
                            "stance": stance,
                            "evidence": [f"{phase}-evidence:{request.seat_id}"],
                            "source_refs": [f"fake://{phase}/{request.seat_id}"],
                            "confidence": 0.95,
                            "novelty": 0.4,
                            "importance": 0.9,
                            "verified": phase == "verify",
                            "verification_notes": ["deterministic test evidence"],
                        }
                    ],
                },
                sort_keys=True,
            )
        seat_number = 0
        try:
            seat_number = int(request.seat_id.rsplit("_", 1)[-1])
        except ValueError:
            pass
        topic = "resilience" if seat_number <= 3 else f"topic-{((seat_number - 1) % 8) + 1}"
        stance = "supports" if seat_number == 1 or seat_number > 3 else "opposes"
        strong = seat_number == 1
        return json.dumps(
            {
                "analysis": f"independent deterministic analysis for {request.seat_id}",
                "findings": [
                    {
                        "claim": f"{request.seat_id} {stance} {topic}",
                        "topic": topic,
                        "stance": stance,
                        "evidence": ["primary artifact", "replicated measurement"] if strong else ["unsupported observation"],
                        "source_refs": ["fake://primary", "fake://replication"] if strong else [],
                        "confidence": 0.97 if strong else 0.55,
                        "novelty": 0.75,
                        "importance": 0.95 if topic == "resilience" else 0.72,
                    }
                ],
            },
            sort_keys=True,
        )

    async def probe(self, model: str) -> bool:
        return True


def build_deterministic_registry(provider_names: set[str]) -> tuple[ProviderRegistry, DeterministicFakeProvider]:
    fake = DeterministicFakeProvider()
    registry = ProviderRegistry(resolve_environment_models=False)
    for name in provider_names:
        registry.register(name, fake)
    return registry, fake


def load_provider_adapter_factory(reference: str) -> ProviderAdapter:
    """Load a zero-argument host adapter factory without accepting credential values."""

    module_name, separator, attribute_name = reference.strip().partition(":")
    if not separator or not module_name or not attribute_name:
        raise ValueError("provider adapter factory must use MODULE:CALLABLE syntax")
    module = importlib.import_module(module_name)
    factory = getattr(module, attribute_name, None)
    if not callable(factory):
        raise ValueError(f"provider adapter factory is not callable: {reference}")
    adapter = factory()
    if not callable(getattr(adapter, "complete", None)):
        raise ValueError("provider adapter factory must return an object with async complete(request)")
    return adapter


def build_live_registry(*, oauth_bridge: ProviderAdapter | None = None) -> ProviderRegistry:
    registry = ProviderRegistry(resolve_environment_models=True)
    registry.register("openai", OpenAIResponsesAdapter())
    registry.register("anthropic", AnthropicMessagesAdapter())
    registry.register("gemini", GeminiGenerateContentAdapter())
    registry.register("xai", OpenAIResponsesAdapter(base_url="https://api.x.ai/v1", api_key_env="XAI_API_KEY"))
    registry.register("groq", OpenAICompatibleChatAdapter("https://api.groq.com/openai/v1", "GROQ_API_KEY"))
    registry.register("openrouter", OpenAICompatibleChatAdapter("https://openrouter.ai/api/v1", "OPENROUTER_API_KEY"))
    registry.register("ollama", OllamaGenerateAdapter())
    if oauth_bridge is not None:
        registry.register("oauth_bridge", oauth_bridge)
    return registry
