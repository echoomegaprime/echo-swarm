from __future__ import annotations

import json
import os
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .control import BudgetPolicy, ExecutionLedger
from .models import (
    CapabilityResult,
    Contradiction,
    Dissent,
    Finding,
    FusionCandidate,
    FusionResult,
    HISTORICAL_PARITY,
    PROFILE_NAME,
    RankedFinding,
    Retask,
    SeatResult,
)


@dataclass(slots=True)
class RunState:
    run_id: str
    objective: str
    caller_context: dict[str, Any]
    status: str = "running"
    last_completed_phase: str = "initialized"
    execution_mode: str = "full"
    selected_seat_ids: list[str] = field(default_factory=list)
    selected_trinity_ids: list[str] = field(default_factory=list)
    budget_policy: BudgetPolicy = field(default_factory=BudgetPolicy)
    execution_ledger: ExecutionLedger = field(default_factory=ExecutionLedger)
    cancel_requested_at: float | None = None
    cancel_reason: str | None = None
    memories: list[dict[str, Any]] = field(default_factory=list)
    memory_reads: list[str] = field(default_factory=list)
    capability_profile: str = "off"
    capability_mode: str = "disabled"
    selected_capability_ids: list[str] = field(default_factory=list)
    capability_results: list[CapabilityResult] = field(default_factory=list)
    subproblems: list[str] = field(default_factory=list)
    assignments: list[dict[str, Any]] = field(default_factory=list)
    first_pass: list[SeatResult] = field(default_factory=list)
    finding_bus: list[Finding] = field(default_factory=list)
    shared_findings: list[Finding] = field(default_factory=list)
    contradictions: list[Contradiction] = field(default_factory=list)
    dissent: list[Dissent] = field(default_factory=list)
    retasks: list[Retask] = field(default_factory=list)
    retask_results: list[SeatResult] = field(default_factory=list)
    critique_results: list[SeatResult] = field(default_factory=list)
    verification_results: list[SeatResult] = field(default_factory=list)
    ranked: list[RankedFinding] = field(default_factory=list)
    candidate: FusionCandidate | None = None
    fusion_passes: int = 0
    result: FusionResult | None = None
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": 5,
            "profile": PROFILE_NAME,
            "historical_parity": HISTORICAL_PARITY,
            "run_id": self.run_id,
            "objective": self.objective,
            "caller_context": self.caller_context,
            "status": self.status,
            "last_completed_phase": self.last_completed_phase,
            "execution_mode": self.execution_mode,
            "selected_seat_ids": self.selected_seat_ids,
            "selected_trinity_ids": self.selected_trinity_ids,
            "budget_policy": self.budget_policy.to_dict(),
            "execution_ledger": self.execution_ledger.to_dict(),
            "cancel_requested_at": self.cancel_requested_at,
            "cancel_reason": self.cancel_reason,
            "memories": self.memories,
            "memory_reads": self.memory_reads,
            "capability_profile": self.capability_profile,
            "capability_mode": self.capability_mode,
            "selected_capability_ids": self.selected_capability_ids,
            "capability_results": [item.to_dict() for item in self.capability_results],
            "subproblems": self.subproblems,
            "assignments": self.assignments,
            "first_pass": [item.to_dict() for item in self.first_pass],
            "finding_bus": [item.to_dict() for item in self.finding_bus],
            "shared_findings": [item.to_dict() for item in self.shared_findings],
            "contradictions": [item.to_dict() for item in self.contradictions],
            "dissent": [item.to_dict() for item in self.dissent],
            "retasks": [item.to_dict() for item in self.retasks],
            "retask_results": [item.to_dict() for item in self.retask_results],
            "critique_results": [item.to_dict() for item in self.critique_results],
            "verification_results": [item.to_dict() for item in self.verification_results],
            "ranked": [item.to_dict() for item in self.ranked],
            "candidate": self.candidate.to_dict() if self.candidate else None,
            "fusion_passes": self.fusion_passes,
            "result": self.result.to_dict() if self.result else None,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RunState":
        if data.get("profile") != PROFILE_NAME or data.get("historical_parity") is not False:
            raise ValueError("checkpoint provenance does not match MAXIMALIST_RECONSTRUCTED")
        return cls(
            run_id=data["run_id"],
            objective=data["objective"],
            caller_context=dict(data.get("caller_context", {})),
            status=data.get("status", "running"),
            last_completed_phase=data.get("last_completed_phase", "initialized"),
            execution_mode=data.get("execution_mode", "full"),
            selected_seat_ids=list(data.get("selected_seat_ids", [])),
            selected_trinity_ids=list(data.get("selected_trinity_ids", [])),
            budget_policy=BudgetPolicy.from_dict(data.get("budget_policy")),
            execution_ledger=ExecutionLedger.from_dict(data.get("execution_ledger")),
            cancel_requested_at=data.get("cancel_requested_at"),
            cancel_reason=data.get("cancel_reason"),
            memories=list(data.get("memories", [])),
            memory_reads=list(data.get("memory_reads", [])),
            capability_profile=str(data.get("capability_profile", "off")),
            capability_mode=str(data.get("capability_mode", "disabled")),
            selected_capability_ids=list(data.get("selected_capability_ids", [])),
            capability_results=[
                CapabilityResult.from_dict(item) for item in data.get("capability_results", [])
            ],
            subproblems=list(data.get("subproblems", [])),
            assignments=list(data.get("assignments", [])),
            first_pass=[SeatResult.from_dict(item) for item in data.get("first_pass", [])],
            finding_bus=[Finding.from_dict(item) for item in data.get("finding_bus", [])],
            shared_findings=[Finding.from_dict(item) for item in data.get("shared_findings", [])],
            contradictions=[Contradiction.from_dict(item) for item in data.get("contradictions", [])],
            dissent=[Dissent.from_dict(item) for item in data.get("dissent", [])],
            retasks=[Retask.from_dict(item) for item in data.get("retasks", [])],
            retask_results=[SeatResult.from_dict(item) for item in data.get("retask_results", [])],
            critique_results=[SeatResult.from_dict(item) for item in data.get("critique_results", [])],
            verification_results=[SeatResult.from_dict(item) for item in data.get("verification_results", [])],
            ranked=[RankedFinding.from_dict(item) for item in data.get("ranked", [])],
            candidate=FusionCandidate.from_dict(data["candidate"]) if data.get("candidate") else None,
            fusion_passes=int(data.get("fusion_passes", 0)),
            result=FusionResult.from_dict(data["result"]) if data.get("result") else None,
            created_at=float(data.get("created_at", time.time())),
            updated_at=float(data.get("updated_at", time.time())),
        )


class JsonRunStateStore:
    def __init__(self, directory: str | Path) -> None:
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)

    def path_for(self, run_id: str) -> Path:
        if not run_id or any(character not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_" for character in run_id):
            raise ValueError("run_id contains unsupported characters")
        return self.directory / f"{run_id}.json"

    def cancel_path_for(self, run_id: str) -> Path:
        self.path_for(run_id)
        return self.directory / f"{run_id}.cancel.json"

    def _cancel_marker(self, run_id: str) -> dict[str, Any] | None:
        target = self.cancel_path_for(run_id)
        if not target.exists():
            return None
        try:
            with target.open("r", encoding="utf-8") as handle:
                marker = json.load(handle)
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            return {
                "requested_at": target.stat().st_mtime,
                "reason": "cancellation marker exists but is unreadable; failing closed",
            }
        return marker if isinstance(marker, dict) and marker.get("requested_at") is not None else None

    def _write_json_atomic(self, target: Path, payload: dict[str, Any], prefix: str) -> None:
        descriptor, temporary = tempfile.mkstemp(prefix=prefix, suffix=".tmp", dir=self.directory)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
                json.dump(payload, handle, indent=2, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, target)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def save(self, state: RunState) -> Path:
        state.updated_at = time.time()
        target = self.path_for(state.run_id)
        marker = self._cancel_marker(state.run_id)
        if marker is not None and state.cancel_requested_at is None:
            state.cancel_requested_at = float(marker["requested_at"])
            state.cancel_reason = str(marker.get("reason") or "operator cancellation requested")
            if state.status not in {"completed", "cancelled", "blocked_uncertain"}:
                state.status = "cancel_requested"
        if target.exists():
            try:
                with target.open("r", encoding="utf-8") as existing_handle:
                    existing = json.load(existing_handle)
                if existing.get("cancel_requested_at") is not None and state.cancel_requested_at is None:
                    state.cancel_requested_at = float(existing["cancel_requested_at"])
                    state.cancel_reason = existing.get("cancel_reason")
                    if state.status not in {"completed", "cancelled", "blocked_uncertain"}:
                        state.status = "cancel_requested"
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                pass
        self._write_json_atomic(target, state.to_dict(), f".{state.run_id}.")
        return target

    def load(self, run_id: str) -> RunState:
        target = self.path_for(run_id)
        with target.open("r", encoding="utf-8") as handle:
            state = RunState.from_dict(json.load(handle))
        marker = self._cancel_marker(run_id)
        if marker is not None:
            state.cancel_requested_at = float(marker["requested_at"])
            state.cancel_reason = str(marker.get("reason") or "operator cancellation requested")
            if state.status not in {"completed", "cancelled", "blocked_uncertain"}:
                state.status = "cancel_requested"
        return state

    def exists(self, run_id: str) -> bool:
        return self.path_for(run_id).exists()

    def cancellation(self, run_id: str) -> tuple[bool, str | None]:
        marker = self._cancel_marker(run_id)
        if marker is not None:
            return True, str(marker.get("reason") or "operator cancellation requested")
        state = self.load(run_id)
        return state.cancel_requested_at is not None, state.cancel_reason

    def request_cancel(self, run_id: str, reason: str | None = None) -> RunState:
        state = self.load(run_id)
        if state.status in {"completed", "cancelled"}:
            return state
        marker = {
            "run_id": run_id,
            "requested_at": time.time(),
            "reason": (reason or "operator cancellation requested").strip()[:500],
        }
        self._write_json_atomic(self.cancel_path_for(run_id), marker, f".{run_id}.cancel.")
        return self.load(run_id)
