from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal


PROFILE_NAME = "MAXIMALIST_RECONSTRUCTED"
HISTORICAL_PARITY = False


def clamp_probability(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        number = default
    return max(0.0, min(1.0, number))


def _string_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value.strip()] if value.strip() else []
    if not isinstance(value, (list, tuple, set)):
        return [str(value)]
    return [str(item).strip() for item in value if str(item).strip()]


@dataclass(slots=True)
class Finding:
    claim: str
    evidence: list[str]
    confidence: float
    novelty: float
    importance: float
    subproblem: str
    source_refs: list[str]
    seat_id: str
    model: str
    role: str
    topic: str = ""
    stance: Literal["supports", "opposes", "neutral"] = "neutral"
    verified: bool = False
    contradicted: bool = False
    verification_notes: list[str] = field(default_factory=list)
    phase: str = "independent"

    def __post_init__(self) -> None:
        self.claim = str(self.claim).strip()
        if not self.claim:
            raise ValueError("finding claim must not be empty")
        self.evidence = _string_list(self.evidence)
        self.source_refs = _string_list(self.source_refs)
        self.verification_notes = _string_list(self.verification_notes)
        self.confidence = clamp_probability(self.confidence)
        self.novelty = clamp_probability(self.novelty)
        self.importance = clamp_probability(self.importance)
        self.topic = str(self.topic or self.claim).strip()
        if self.stance not in {"supports", "opposes", "neutral"}:
            self.stance = "neutral"

    @property
    def finding_id(self) -> str:
        return f"{self.seat_id}:{self.phase}:{self.topic}:{self.stance}:{self.claim}"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Finding":
        allowed = cls.__dataclass_fields__.keys()
        return cls(**{key: value for key, value in data.items() if key in allowed})


@dataclass(slots=True)
class SeatResult:
    seat_id: str
    model: str
    role: str
    subproblem: str
    raw_output: str
    findings: list[Finding]
    confidence: float = 0.0
    latency_ms: int = 0
    error: str | None = None
    phase: str = "independent"

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["findings"] = [finding.to_dict() for finding in self.findings]
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SeatResult":
        return cls(
            seat_id=data["seat_id"],
            model=data["model"],
            role=data["role"],
            subproblem=data.get("subproblem", ""),
            raw_output=data.get("raw_output", ""),
            findings=[Finding.from_dict(item) for item in data.get("findings", [])],
            confidence=clamp_probability(data.get("confidence", 0.0)),
            latency_ms=int(data.get("latency_ms", 0)),
            error=data.get("error"),
            phase=data.get("phase", "independent"),
        )


@dataclass(slots=True)
class CapabilityResult:
    """Bounded, redacted evidence returned by a non-LLM capability."""

    capability_id: str
    status: Literal[
        "completed",
        "skipped",
        "unauthorized",
        "unavailable",
        "timed_out",
        "failed",
    ]
    payload: dict[str, Any] = field(default_factory=dict)
    source_refs: list[str] = field(default_factory=list)
    required_scope: str = ""
    danger_tier: int = 0
    read_only: bool = True
    latency_ms: int = 0
    error: str | None = None
    payload_sha256: str | None = None
    truncated: bool = False

    def __post_init__(self) -> None:
        self.capability_id = str(self.capability_id).strip()
        if not self.capability_id:
            raise ValueError("capability_id must not be empty")
        if self.status not in {
            "completed",
            "skipped",
            "unauthorized",
            "unavailable",
            "timed_out",
            "failed",
        }:
            raise ValueError(f"unsupported capability result status: {self.status}")
        self.payload = dict(self.payload or {})
        self.source_refs = _string_list(self.source_refs)
        self.required_scope = str(self.required_scope or "")
        self.danger_tier = max(0, int(self.danger_tier))
        self.latency_ms = max(0, int(self.latency_ms))
        self.error = str(self.error).strip() if self.error else None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_context(self) -> dict[str, Any]:
        return {
            "capability_id": self.capability_id,
            "status": self.status,
            "payload": dict(self.payload),
            "source_refs": list(self.source_refs),
            "payload_sha256": self.payload_sha256,
            "truncated": self.truncated,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CapabilityResult":
        allowed = cls.__dataclass_fields__.keys()
        return cls(**{key: value for key, value in data.items() if key in allowed})


@dataclass(slots=True)
class Contradiction:
    topic: str
    supporting_claims: list[str]
    opposing_claims: list[str]
    supporting_seats: list[str]
    opposing_seats: list[str]
    evidence: list[str]
    resolved: bool = False
    resolution: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Contradiction":
        return cls(**data)


@dataclass(slots=True)
class Dissent:
    claim: str
    dissenting_seats: list[str]
    majority_position: str
    evidence: list[str]
    confidence: float
    topic: str = ""
    reason_rejected: str | None = None
    vindicated: bool | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Dissent":
        return cls(**data)


@dataclass(slots=True)
class Retask:
    seat_id: str
    subproblem: str
    reason: str
    findings_to_inspect: list[Finding]
    kind: Literal["verify", "refute", "extend", "critique"] = "verify"

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["findings_to_inspect"] = [item.to_dict() for item in self.findings_to_inspect]
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Retask":
        return cls(
            seat_id=data["seat_id"],
            subproblem=data["subproblem"],
            reason=data["reason"],
            findings_to_inspect=[Finding.from_dict(item) for item in data.get("findings_to_inspect", [])],
            kind=data.get("kind", "verify"),
        )


@dataclass(slots=True)
class RankedFinding:
    finding: Finding
    score: float
    score_components: dict[str, float]

    def to_dict(self) -> dict[str, Any]:
        return {
            "finding": self.finding.to_dict(),
            "score": self.score,
            "score_components": dict(self.score_components),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RankedFinding":
        return cls(
            finding=Finding.from_dict(data["finding"]),
            score=float(data["score"]),
            score_components={key: float(value) for key, value in data.get("score_components", {}).items()},
        )


@dataclass(slots=True)
class ClaimCluster:
    cluster_id: str
    topic: str
    canonical_claim: str
    supporting_finding_ids: list[str]
    opposing_finding_ids: list[str]
    neutral_finding_ids: list[str]
    provider_families: list[str]
    independence_groups: list[str]
    validated_source_refs: list[str]
    unverified_source_refs: list[str]
    support_score: float
    refutation_score: float
    status: Literal["supported", "contested", "refuted", "unresolved"]

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["support_score"] = clamp_probability(self.support_score)
        data["refutation_score"] = clamp_probability(self.refutation_score)
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ClaimCluster":
        return cls(**data)


@dataclass(slots=True)
class SeatContribution:
    seat_id: str
    provider: str
    model: str
    role: str
    phases: list[str]
    calls: int
    successful_calls: int
    findings: int
    verified_findings: int
    selected_findings: int
    dissent_mentions: int
    latency_ms: int
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SeatContribution":
        return cls(**data)


@dataclass(slots=True)
class CoverageReport:
    selected_seats: int
    configured_seats: int
    selection_ratio: float
    successful_seats: int
    provider_families: list[str]
    independence_groups: list[str]
    roles: list[str]
    domains: list[str]
    evidence_sources: int
    validated_evidence_sources: int
    unresolved_dissent: int
    degraded_capabilities: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CoverageReport":
        value = dict(data)
        selected = max(0, int(value.get("selected_seats", 0)))
        configured = max(selected, int(value.get("configured_seats", selected)))
        value["selected_seats"] = selected
        value["configured_seats"] = configured
        value["selection_ratio"] = float(
            value.get("selection_ratio", selected / configured if configured else 0.0)
        )
        return cls(**value)


@dataclass(slots=True)
class FusionCandidate:
    answer: str
    confidence: float
    supported_claims: list[str]
    weak_claims: list[str]
    unresolved: list[str]
    trinity_views: list[dict[str, Any]] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.answer = str(self.answer).strip()
        self.confidence = clamp_probability(self.confidence)
        self.supported_claims = _string_list(self.supported_claims)
        self.weak_claims = _string_list(self.weak_claims)
        self.unresolved = _string_list(self.unresolved)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FusionCandidate":
        return cls(**data)


@dataclass(slots=True)
class FusionResult:
    run_id: str
    answer: str
    confidence: float
    major_findings: list[Finding]
    dissent: list[Dissent]
    unresolved: list[str]
    models_used: list[str]
    retasks: list[Retask]
    fusion_passes: int
    memory_reads: list[str]
    memory_writes: list[str]
    provenance: dict[str, Any]
    contradictions: list[Contradiction] = field(default_factory=list)
    performance_updates: list[dict[str, Any]] = field(default_factory=list)
    performance_writes: list[str] = field(default_factory=list)
    capability_results: list[CapabilityResult] = field(default_factory=list)
    claim_clusters: list[ClaimCluster] = field(default_factory=list)
    seat_contributions: list[SeatContribution] = field(default_factory=list)
    coverage: CoverageReport | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "answer": self.answer,
            "confidence": clamp_probability(self.confidence),
            "major_findings": [item.to_dict() for item in self.major_findings],
            "dissent": [item.to_dict() for item in self.dissent],
            "unresolved": list(self.unresolved),
            "models_used": list(self.models_used),
            "retasks": [item.to_dict() for item in self.retasks],
            "fusion_passes": self.fusion_passes,
            "memory_reads": list(self.memory_reads),
            "memory_writes": list(self.memory_writes),
            "provenance": dict(self.provenance),
            "contradictions": [item.to_dict() for item in self.contradictions],
            "performance_updates": list(self.performance_updates),
            "performance_writes": list(self.performance_writes),
            "capability_results": [item.to_dict() for item in self.capability_results],
            "claim_clusters": [item.to_dict() for item in self.claim_clusters],
            "seat_contributions": [item.to_dict() for item in self.seat_contributions],
            "coverage": self.coverage.to_dict() if self.coverage else None,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FusionResult":
        return cls(
            run_id=data["run_id"],
            answer=data.get("answer", ""),
            confidence=clamp_probability(data.get("confidence", 0.0)),
            major_findings=[Finding.from_dict(item) for item in data.get("major_findings", [])],
            dissent=[Dissent.from_dict(item) for item in data.get("dissent", [])],
            unresolved=list(data.get("unresolved", [])),
            models_used=list(data.get("models_used", [])),
            retasks=[Retask.from_dict(item) for item in data.get("retasks", [])],
            fusion_passes=int(data.get("fusion_passes", 0)),
            memory_reads=list(data.get("memory_reads", [])),
            memory_writes=list(data.get("memory_writes", [])),
            provenance=dict(data.get("provenance", {})),
            contradictions=[Contradiction.from_dict(item) for item in data.get("contradictions", [])],
            performance_updates=list(data.get("performance_updates", [])),
            performance_writes=list(data.get("performance_writes", [])),
            capability_results=[
                CapabilityResult.from_dict(item) for item in data.get("capability_results", [])
            ],
            claim_clusters=[ClaimCluster.from_dict(item) for item in data.get("claim_clusters", [])],
            seat_contributions=[
                SeatContribution.from_dict(item) for item in data.get("seat_contributions", [])
            ],
            coverage=CoverageReport.from_dict(data["coverage"]) if data.get("coverage") else None,
        )
