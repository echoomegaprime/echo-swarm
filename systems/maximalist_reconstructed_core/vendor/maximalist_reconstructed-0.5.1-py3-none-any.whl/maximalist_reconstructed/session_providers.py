from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol

from .providers import ProviderCompletion, ProviderError, ProviderRequest


_SAFE_MODEL = re.compile(r"^[A-Za-z0-9._:/-]{1,200}$")


@dataclass(slots=True)
class SessionCommandResult:
    return_code: int
    stdout: str
    stderr: str


class SessionCommandRunner(Protocol):
    async def run(
        self,
        executable: str,
        arguments: list[str],
        *,
        input_text: str,
        working_directory: Path,
    ) -> SessionCommandResult:
        ...


@dataclass(slots=True)
class AsyncSubprocessRunner:
    max_output_bytes: int = 4 * 1024 * 1024

    async def run(
        self,
        executable: str,
        arguments: list[str],
        *,
        input_text: str,
        working_directory: Path,
    ) -> SessionCommandResult:
        resolved = shutil.which(executable)
        if resolved is None:
            raise ProviderError(f"host session command is unavailable: {executable}")
        command: list[str]
        if os.name == "nt" and Path(resolved).suffix.lower() in {".bat", ".cmd"}:
            command = [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/s", "/c", resolved, *arguments]
        else:
            command = [resolved, *arguments]
        creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        process = await asyncio.create_subprocess_exec(
            *command,
            cwd=str(working_directory),
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            creationflags=creationflags,
        )
        try:
            stdout, stderr = await process.communicate(input=input_text.encode("utf-8"))
        except asyncio.CancelledError:
            process.kill()
            await process.wait()
            raise
        if len(stdout) > self.max_output_bytes or len(stderr) > self.max_output_bytes:
            raise ProviderError("host session command exceeded the bounded output limit")
        return SessionCommandResult(
            return_code=int(process.returncode or 0),
            stdout=stdout.decode("utf-8", errors="replace"),
            stderr=stderr.decode("utf-8", errors="replace"),
        )


@dataclass(slots=True)
class HostSessionAdapter:
    working_directory: Path
    command: str
    runner: SessionCommandRunner = field(default_factory=AsyncSubprocessRunner)
    readiness_timeout_seconds: float = 20.0
    authentication_mode: str = field(default="host_session", init=False)
    metering_mode: str = field(default="host_subscription", init=False)
    probe_verifies_network: bool = field(default=False, init=False)
    last_usage: dict[str, int] = field(default_factory=dict, init=False)

    def __post_init__(self) -> None:
        self.working_directory = Path(self.working_directory).resolve()
        self.working_directory.mkdir(parents=True, exist_ok=True)
        if self.readiness_timeout_seconds <= 0:
            raise ValueError("readiness timeout must be positive")

    @staticmethod
    def _model_argument(model: str) -> str | None:
        normalized = model.strip()
        if normalized.lower() in {"default", "session-default"}:
            return None
        if not _SAFE_MODEL.fullmatch(normalized):
            raise ProviderError("session model identifier contains unsupported characters")
        return normalized

    @staticmethod
    def _retryable(result: SessionCommandResult) -> bool:
        combined = f"{result.stdout}\n{result.stderr}".lower()
        if "weekly limit" in combined or "usage limit" in combined:
            return False
        return any(
            marker in combined
            for marker in ("429", "temporarily unavailable", "overloaded", "timed out", "connection reset")
        )

    def _failure(self, result: SessionCommandResult) -> ProviderError:
        return ProviderError(
            f"{self.command} host session call failed with exit code {result.return_code}",
            retryable=self._retryable(result),
        )

    @staticmethod
    def _completion(text: str, usage: dict[str, int], source: str) -> ProviderCompletion:
        def first(*keys: str) -> int | None:
            for key in keys:
                value = usage.get(key)
                if isinstance(value, int) and value >= 0:
                    return value
            return None

        cached_values = [
            value
            for key in (
                "cached_input_tokens",
                "cache_read_input_tokens",
                "cache_creation_input_tokens",
            )
            if isinstance((value := usage.get(key)), int) and value >= 0
        ]
        return ProviderCompletion(
            text=text,
            input_tokens=first("input_tokens", "inputTokens", "prompt_tokens"),
            cached_input_tokens=sum(cached_values) if cached_values else None,
            output_tokens=first("output_tokens", "outputTokens", "completion_tokens"),
            usage_source=source,
        )


@dataclass(slots=True)
class CodexSessionAdapter(HostSessionAdapter):
    command: str = "codex"

    async def probe(self, model: str) -> bool:
        try:
            result = await asyncio.wait_for(
                self.runner.run(
                    self.command,
                    ["login", "status"],
                    input_text="",
                    working_directory=self.working_directory,
                ),
                timeout=self.readiness_timeout_seconds,
            )
        except (OSError, ProviderError, TimeoutError):
            return False
        combined = f"{result.stdout}\n{result.stderr}".lower()
        return result.return_code == 0 and "logged in" in combined

    async def complete(self, request: ProviderRequest) -> ProviderCompletion:
        arguments = [
            "exec",
            "-",
            "--sandbox",
            "read-only",
            "--skip-git-repo-check",
            "--ephemeral",
            "--ignore-user-config",
            "--ignore-rules",
            "--color",
            "never",
            "--cd",
            str(self.working_directory),
            "--json",
            "-c",
            "mcp_servers={}",
        ]
        for feature in (
            "apps",
            "browser_use",
            "computer_use",
            "hooks",
            "image_generation",
            "in_app_browser",
            "plugins",
            "remote_plugin",
            "shell_tool",
            "skill_mcp_dependency_install",
            "tool_suggest",
            "unified_exec",
            "view_image",
        ):
            arguments.extend(("--disable", feature))
        model = self._model_argument(request.model)
        if model is not None:
            arguments.extend(("--model", model))
        result = await self.runner.run(
            self.command,
            arguments,
            input_text=request.prompt,
            working_directory=self.working_directory,
        )
        if result.return_code != 0:
            raise self._failure(result)
        messages: list[str] = []
        usage: dict[str, int] = {}
        for line in result.stdout.splitlines():
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(event, dict):
                continue
            item = event.get("item")
            if (
                event.get("type") == "item.completed"
                and isinstance(item, dict)
                and item.get("type") == "agent_message"
                and isinstance(item.get("text"), str)
            ):
                messages.append(item["text"])
            if event.get("type") == "turn.completed" and isinstance(event.get("usage"), dict):
                usage = {
                    key: int(value)
                    for key, value in event["usage"].items()
                    if isinstance(value, (int, float))
                }
        if not messages:
            raise ProviderError("Codex host session returned no final agent message")
        self.last_usage = usage
        return self._completion(messages[-1], usage, "codex_session")


@dataclass(slots=True)
class ClaudeSessionAdapter(HostSessionAdapter):
    command: str = "claude"

    async def probe(self, model: str) -> bool:
        try:
            result = await asyncio.wait_for(
                self.runner.run(
                    self.command,
                    ["auth", "status"],
                    input_text="",
                    working_directory=self.working_directory,
                ),
                timeout=self.readiness_timeout_seconds,
            )
            payload = json.loads(result.stdout)
        except (OSError, ProviderError, TimeoutError, json.JSONDecodeError):
            return False
        return result.return_code == 0 and isinstance(payload, dict) and payload.get("loggedIn") is True

    async def complete(self, request: ProviderRequest) -> ProviderCompletion:
        arguments = [
            "-p",
            "--output-format",
            "json",
            "--permission-mode",
            "plan",
            "--tools=",
            "--no-session-persistence",
            "--safe-mode",
            "--disable-slash-commands",
            "--effort",
            "low",
        ]
        model = self._model_argument(request.model)
        if model is not None:
            arguments.extend(("--model", model))
        result = await self.runner.run(
            self.command,
            arguments,
            input_text=request.prompt,
            working_directory=self.working_directory,
        )
        try:
            payload = json.loads(result.stdout)
        except json.JSONDecodeError:
            payload = None
        if result.return_code != 0 or not isinstance(payload, dict) or payload.get("is_error") is True:
            raise self._failure(result)
        text = payload.get("result")
        if not isinstance(text, str) or not text.strip():
            raise ProviderError("Claude host session returned no result text")
        usage = payload.get("usage", {})
        self.last_usage = {
            key: int(value)
            for key, value in usage.items()
            if isinstance(value, (int, float))
        } if isinstance(usage, dict) else {}
        return self._completion(text, self.last_usage, "claude_session")


@dataclass(slots=True)
class GeminiSessionAdapter(HostSessionAdapter):
    command: str = "gemini"

    async def probe(self, model: str) -> bool:
        if shutil.which(self.command) is None:
            return False
        for variable in ("GEMINI_API_KEY", "GOOGLE_GENAI_USE_VERTEXAI", "GOOGLE_GENAI_USE_GCA"):
            if os.environ.get(variable, "").strip():
                return True
        settings = Path.home() / ".gemini" / "settings.json"
        try:
            payload = json.loads(settings.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return False
        serialized = json.dumps(payload).lower()
        return any(marker in serialized for marker in ("selectedauthtype", "oauth-personal", "login-with-google"))

    async def complete(self, request: ProviderRequest) -> ProviderCompletion:
        arguments = [
            "--prompt",
            "",
            "--output-format",
            "json",
            "--approval-mode",
            "plan",
            "--skip-trust",
        ]
        model = self._model_argument(request.model)
        if model is not None:
            arguments.extend(("--model", model))
        result = await self.runner.run(
            self.command,
            arguments,
            input_text=request.prompt,
            working_directory=self.working_directory,
        )
        try:
            payload = json.loads(result.stdout)
        except json.JSONDecodeError:
            payload = None
        if result.return_code != 0 or not isinstance(payload, dict) or isinstance(payload.get("error"), dict):
            raise self._failure(result)
        text = next(
            (
                payload.get(key)
                for key in ("response", "result", "output")
                if isinstance(payload.get(key), str) and payload.get(key).strip()
            ),
            None,
        )
        if not isinstance(text, str):
            raise ProviderError("Gemini host session returned no result text")
        stats = payload.get("stats", {})
        self.last_usage = {
            key: int(value)
            for key, value in stats.items()
            if isinstance(value, (int, float))
        } if isinstance(stats, dict) else {}
        return self._completion(text, self.last_usage, "gemini_session")


def build_session_adapter(name: str, working_directory: str | Path) -> HostSessionAdapter:
    normalized = name.strip().lower()
    adapters = {
        "codex": CodexSessionAdapter,
        "claude": ClaudeSessionAdapter,
        "gemini": GeminiSessionAdapter,
    }
    adapter = adapters.get(normalized)
    if adapter is None:
        raise ValueError(f"unsupported host session provider: {name}")
    return adapter(working_directory=Path(working_directory))
