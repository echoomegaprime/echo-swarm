from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

from .models import Finding, clamp_probability


_FENCE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.IGNORECASE)
_KEY_VALUE = re.compile(r"^\s*-?\s*([A-Za-z_ ]+?)\s*:\s*(.*?)\s*$")


@dataclass(slots=True)
class ParsedProviderOutput:
    analysis: str
    findings: list[Finding]


def _as_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        value = value.strip()
        if not value:
            return []
        if value.startswith("["):
            try:
                decoded = json.loads(value)
                if isinstance(decoded, list):
                    return [str(item).strip() for item in decoded if str(item).strip()]
            except json.JSONDecodeError:
                pass
        return [item.strip() for item in value.split("|") if item.strip()]
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    return [str(value)]


def _finding_from_mapping(
    item: dict[str, Any],
    *,
    seat_id: str,
    model: str,
    role: str,
    subproblem: str,
    phase: str,
) -> Finding | None:
    claim = str(item.get("claim", "")).strip()
    if not claim:
        return None
    stance = str(item.get("stance", "neutral")).strip().lower()
    if stance not in {"supports", "opposes", "neutral"}:
        stance = "neutral"
    return Finding(
        claim=claim,
        evidence=_as_list(item.get("evidence")),
        confidence=clamp_probability(item.get("confidence", 0.5), 0.5),
        novelty=clamp_probability(item.get("novelty", 0.5), 0.5),
        importance=clamp_probability(item.get("importance", 0.5), 0.5),
        subproblem=subproblem,
        source_refs=_as_list(item.get("source_refs")),
        seat_id=seat_id,
        model=model,
        role=role,
        topic=str(item.get("topic", claim)).strip(),
        stance=stance,
        verified=bool(item.get("verified", False)),
        verification_notes=_as_list(item.get("verification_notes")),
        phase=phase,
    )


def _try_json(raw: str) -> tuple[str, list[dict[str, Any]]] | None:
    cleaned = _FENCE.sub("", raw.strip()).strip()
    candidates = [cleaned]
    first_object = cleaned.find("{")
    last_object = cleaned.rfind("}")
    if first_object >= 0 and last_object > first_object:
        candidates.append(cleaned[first_object : last_object + 1])
    first_array = cleaned.find("[")
    last_array = cleaned.rfind("]")
    if first_array >= 0 and last_array > first_array:
        candidates.append(cleaned[first_array : last_array + 1])
    for candidate in candidates:
        try:
            data = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(data, list):
            return "", [item for item in data if isinstance(item, dict)]
        if isinstance(data, dict):
            findings = data.get("findings", [])
            if isinstance(findings, dict):
                findings = [findings]
            if isinstance(findings, list):
                return str(data.get("analysis", "")), [item for item in findings if isinstance(item, dict)]
    return None


def _parse_labeled(raw: str) -> tuple[str, list[dict[str, Any]]]:
    analysis_lines: list[str] = []
    findings: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    in_findings = False
    for line in raw.splitlines():
        stripped = line.strip()
        if stripped.upper() == "FINDINGS:":
            in_findings = True
            continue
        if stripped.upper() == "ANALYSIS:":
            in_findings = False
            continue
        match = _KEY_VALUE.match(line)
        if in_findings and match:
            key = match.group(1).strip().lower().replace(" ", "_")
            value = match.group(2).strip()
            if key == "claim":
                if current and current.get("claim"):
                    findings.append(current)
                current = {"claim": value}
            elif current is not None:
                current[key] = value
            continue
        if not in_findings and stripped:
            analysis_lines.append(stripped)
    if current and current.get("claim"):
        findings.append(current)
    return "\n".join(analysis_lines), findings


def parse_provider_output(
    raw: str,
    *,
    seat_id: str,
    model: str,
    role: str,
    subproblem: str,
    phase: str,
) -> ParsedProviderOutput:
    if not isinstance(raw, str):
        raise TypeError("provider output must be text")
    parsed = _try_json(raw)
    if parsed is None:
        parsed = _parse_labeled(raw)
    analysis, mappings = parsed
    findings = []
    for item in mappings:
        finding = _finding_from_mapping(
            item,
            seat_id=seat_id,
            model=model,
            role=role,
            subproblem=subproblem,
            phase=phase,
        )
        if finding is not None:
            findings.append(finding)
    return ParsedProviderOutput(analysis=analysis, findings=findings)
