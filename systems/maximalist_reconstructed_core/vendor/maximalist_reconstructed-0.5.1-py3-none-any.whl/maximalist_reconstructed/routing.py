from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from typing import Any, Literal

from .config import SeatConfig, SeatRegistry
from .models import HISTORICAL_PARITY, PROFILE_NAME


RoutingPolicy = Literal[
    "full_40",
    "adaptive",
    "cost_bounded",
    "latency_bounded",
    "offline_private",
    "high_assurance",
    "canary",
    "explicit",
]


DOMAIN_TERMS: dict[str, tuple[str, ...]] = {
    "code": ("code", "program", "debug", "algorithm", "function", "script", "repository"),
    "security": ("security", "vulnerability", "exploit", "threat", "attack", "credential", "auth"),
    "mathematics": ("math", "equation", "calculate", "formula", "proof", "wolfram"),
    "research": ("research", "paper", "source", "evidence", "literature", "study"),
    "memory": ("memory", "continuity", "context", "crystal", "recall", "knowledge"),
    "integration": ("integrate", "integration", "endpoint", "adapter", "sdk", "plugin", "mcp"),
    "planning": ("plan", "roadmap", "sequence", "milestone", "schedule"),
    "risk": ("risk", "failure", "rollback", "recovery", "safety", "impact"),
    "history": ("historical", "history", "archive", "recovered", "provenance", "forensic"),
    "finance": ("finance", "market", "stock", "crypto", "trading", "economy"),
    "medical": ("medical", "health", "diagnosis", "symptom", "treatment"),
    "legal": ("legal", "law", "contract", "compliance", "regulation"),
    "current_events": ("current", "today", "latest", "news", "recent"),
}

SENSITIVE_TERMS = ("secret", "credential", "private", "personal", "confidential", "proprietary")
HIGH_RISK_TERMS = (
    "production",
    "deploy",
    "delete",
    "security",
    "credential",
    "financial",
    "medical",
    "legal",
    "irreversible",
)


@dataclass(frozen=True, slots=True)
class TaskProfile:
    domains: tuple[str, ...]
    high_risk: bool = False
    privacy_sensitive: bool = False
    freshness_required: bool = False

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["domains"] = list(self.domains)
        return data


@dataclass(slots=True)
class SelectionReceipt:
    policy: RoutingPolicy
    selected_seat_ids: list[str]
    eligible_seat_ids: list[str]
    selection_reasons: dict[str, list[str]]
    task_profile: TaskProfile
    provider_families: list[str]
    independence_groups: list[str]
    objective_sha256: str
    routing_fingerprint: str = ""
    profile: str = PROFILE_NAME
    historical_parity: bool = HISTORICAL_PARITY

    def __post_init__(self) -> None:
        if self.profile != PROFILE_NAME or self.historical_parity is not False:
            raise ValueError("routing receipt provenance must be MAXIMALIST_RECONSTRUCTED")
        if not self.selected_seat_ids:
            raise ValueError("routing selected no seats")
        if len(self.selected_seat_ids) != len(set(self.selected_seat_ids)):
            raise ValueError("routing selected duplicate seats")
        if not set(self.selected_seat_ids).issubset(self.eligible_seat_ids):
            raise ValueError("routing selected an ineligible seat")
        if not self.routing_fingerprint:
            payload = self.to_dict(include_fingerprint=False)
            encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
            self.routing_fingerprint = hashlib.sha256(encoded).hexdigest()

    def to_dict(self, *, include_fingerprint: bool = True) -> dict[str, Any]:
        data = {
            "profile": self.profile,
            "historical_parity": self.historical_parity,
            "policy": self.policy,
            "selected_seat_ids": list(self.selected_seat_ids),
            "eligible_seat_ids": list(self.eligible_seat_ids),
            "selection_reasons": {key: list(value) for key, value in self.selection_reasons.items()},
            "task_profile": self.task_profile.to_dict(),
            "provider_families": list(self.provider_families),
            "independence_groups": list(self.independence_groups),
            "objective_sha256": self.objective_sha256,
        }
        if include_fingerprint:
            data["routing_fingerprint"] = self.routing_fingerprint
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SelectionReceipt":
        task = dict(data.get("task_profile") or {})
        return cls(
            profile=str(data.get("profile") or PROFILE_NAME),
            historical_parity=bool(data.get("historical_parity", False)),
            policy=str(data.get("policy") or "explicit"),  # type: ignore[arg-type]
            selected_seat_ids=list(data.get("selected_seat_ids") or []),
            eligible_seat_ids=list(data.get("eligible_seat_ids") or []),
            selection_reasons={
                str(key): [str(item) for item in value]
                for key, value in dict(data.get("selection_reasons") or {}).items()
            },
            task_profile=TaskProfile(
                domains=tuple(str(item) for item in task.get("domains") or ("general",)),
                high_risk=bool(task.get("high_risk", False)),
                privacy_sensitive=bool(task.get("privacy_sensitive", False)),
                freshness_required=bool(task.get("freshness_required", False)),
            ),
            provider_families=[str(item) for item in data.get("provider_families") or []],
            independence_groups=[str(item) for item in data.get("independence_groups") or []],
            objective_sha256=str(data.get("objective_sha256") or ""),
            routing_fingerprint=str(data.get("routing_fingerprint") or ""),
        )


class SeatRouter:
    """Deterministic, provenance-bearing seat selection.

    The historical v9.5 keyword router informed the domain concept, but this
    implementation is a modern reconstruction: it is deterministic, bounded,
    health-eligible, role-aware, and never claims historical parity.
    """

    DEFAULT_LIMITS: dict[str, int] = {
        "adaptive": 12,
        "cost_bounded": 8,
        "latency_bounded": 8,
        "offline_private": 12,
        "high_assurance": 20,
        "canary": 4,
    }

    @staticmethod
    def classify(objective: str) -> TaskProfile:
        lowered = objective.lower()
        domains = [
            domain
            for domain, terms in DOMAIN_TERMS.items()
            if any(re.search(rf"\b{re.escape(term)}", lowered) for term in terms)
        ]
        return TaskProfile(
            domains=tuple(domains or ["general"]),
            high_risk=any(term in lowered for term in HIGH_RISK_TERMS),
            privacy_sensitive=any(term in lowered for term in SENSITIVE_TERMS),
            freshness_required=any(term in lowered for term in DOMAIN_TERMS["current_events"]),
        )

    @staticmethod
    def _family(seat: SeatConfig) -> str:
        return seat.provider_family or seat.provider

    @staticmethod
    def _independence(seat: SeatConfig) -> str:
        return seat.independence_group or seat.provider_family or seat.provider

    @staticmethod
    def _seat_domains(seat: SeatConfig) -> set[str]:
        return {item.lower() for item in (*seat.domains, *seat.specializations)}

    def _score(
        self,
        seat: SeatConfig,
        task: TaskProfile,
        policy: RoutingPolicy,
        performance: dict[str, dict[str, float]],
    ) -> tuple[float, list[str]]:
        reasons: list[str] = []
        domains = self._seat_domains(seat)
        matches = sorted(domains.intersection(task.domains))
        score = 10.0 * len(matches)
        reasons.extend(f"domain:{item}" for item in matches)

        if "general" in domains or seat.role in {"general_reasoner", "decomposer", "planner"}:
            score += 2.0
            reasons.append("general_reasoning")
        if seat.role in {"critic", "adversarial_critic", "skeptic"}:
            score += 2.0
            reasons.append("independent_critique")
        if seat.role in {"verifier", "provenance_auditor"}:
            score += 2.5
            reasons.append("verification")
        if task.high_risk and seat.role in {"security_reviewer", "risk_analyst", "provenance_auditor"}:
            score += 6.0
            reasons.append("high_risk_control")
        if task.privacy_sensitive and seat.privacy_class in {"local", "private"}:
            score += 5.0
            reasons.append("privacy_match")
        if policy == "cost_bounded" and seat.cost_class in {"free", "low"}:
            score += 6.0
            reasons.append("cost_preference")
        if policy == "latency_bounded" and seat.latency_class == "fast":
            score += 6.0
            reasons.append("latency_preference")
        if policy == "offline_private" and seat.locality in {"local", "fleet"}:
            score += 8.0
            reasons.append("offline_private")

        calibrated = float(performance.get(seat.model, {}).get("domain_score", 0.5))
        score += max(0.0, min(1.0, calibrated)) * 2.0
        reasons.append(f"calibrated_performance:{calibrated:.3f}")
        return score, reasons

    def select(
        self,
        objective: str,
        registry: SeatRegistry,
        *,
        policy: RoutingPolicy = "full_40",
        eligible_seat_ids: list[str] | None = None,
        max_seats: int | None = None,
        performance: dict[str, dict[str, float]] | None = None,
    ) -> SelectionReceipt:
        if policy not in {
            "full_40",
            "adaptive",
            "cost_bounded",
            "latency_bounded",
            "offline_private",
            "high_assurance",
            "canary",
        }:
            raise ValueError(f"unsupported routing policy: {policy}")
        eligible = set(eligible_seat_ids or [seat.id for seat in registry.enabled_seats])
        candidates = [seat for seat in registry.enabled_seats if seat.id in eligible]
        if eligible_seat_ids is not None:
            unknown = sorted(eligible - {seat.id for seat in registry.enabled_seats})
            if unknown:
                raise ValueError(f"routing eligibility contains unknown seats: {unknown}")
        if policy == "offline_private":
            candidates = [
                seat
                for seat in candidates
                if seat.locality in {"local", "fleet"} and seat.privacy_class in {"local", "private"}
            ]
        if not candidates:
            raise ValueError("routing has no eligible seats")

        task = self.classify(objective)
        objective_sha256 = hashlib.sha256(objective.encode("utf-8")).hexdigest()
        scores = {
            seat.id: self._score(seat, task, policy, performance or {})
            for seat in candidates
        }

        if policy == "full_40":
            selected = list(candidates)
            reasons = {seat.id: ["full_40"] for seat in selected}
        else:
            target = max_seats or self.DEFAULT_LIMITS[policy]
            if target <= 0:
                raise ValueError("routing max_seats must be positive")
            target = min(target, len(candidates))
            selected = []
            reasons: dict[str, list[str]] = {}

            mandatory_role_groups = [
                {"general_reasoner", "decomposer", "planner"},
                {"critic", "adversarial_critic", "skeptic"},
                {"verifier", "provenance_auditor"},
            ]
            if task.high_risk or policy == "high_assurance":
                mandatory_role_groups.extend(
                    [
                        {"security_reviewer"},
                        {"risk_analyst"},
                        {"provenance_auditor"},
                    ]
                )

            def order(items: list[SeatConfig]) -> list[SeatConfig]:
                return sorted(items, key=lambda seat: (-scores[seat.id][0], seat.id))

            def add(seat: SeatConfig, reason: str) -> None:
                if seat.id in {item.id for item in selected} or len(selected) >= target:
                    return
                selected.append(seat)
                reasons[seat.id] = [reason, *scores[seat.id][1]]

            for roles in mandatory_role_groups:
                options = [seat for seat in candidates if seat.role in roles]
                if options:
                    unused_family = [seat for seat in options if self._family(seat) not in {self._family(item) for item in selected}]
                    add(order(unused_family or options)[0], f"mandatory_role:{sorted(roles)[0]}")

            for domain in task.domains:
                options = [seat for seat in candidates if domain in self._seat_domains(seat)]
                if options:
                    add(order(options)[0], f"mandatory_domain:{domain}")

            while len(selected) < target:
                remaining = [seat for seat in candidates if seat.id not in {item.id for item in selected}]
                if not remaining:
                    break
                used_families = {self._family(item) for item in selected}
                used_groups = {self._independence(item) for item in selected}
                ranked = sorted(
                    remaining,
                    key=lambda seat: (
                        -(scores[seat.id][0]
                          + (3.0 if self._family(seat) not in used_families else 0.0)
                          + (2.0 if self._independence(seat) not in used_groups else 0.0)),
                        seat.id,
                    ),
                )
                add(ranked[0], "diversity_fill")

        return SelectionReceipt(
            policy=policy,
            selected_seat_ids=[seat.id for seat in selected],
            eligible_seat_ids=[seat.id for seat in candidates],
            selection_reasons=reasons,
            task_profile=task,
            provider_families=sorted({self._family(seat) for seat in selected}),
            independence_groups=sorted({self._independence(seat) for seat in selected}),
            objective_sha256=objective_sha256,
        )

    def explicit(
        self,
        objective: str,
        registry: SeatRegistry,
        selected_seat_ids: list[str],
    ) -> SelectionReceipt:
        selected = list(dict.fromkeys(selected_seat_ids))
        configured = {seat.id: seat for seat in registry.enabled_seats}
        unknown = sorted(set(selected) - set(configured))
        if unknown:
            raise ValueError(f"selected seat identifiers are not configured: {unknown}")
        if not selected:
            raise ValueError("at least one swarm seat must be selected")
        seats = [configured[seat_id] for seat_id in selected]
        return SelectionReceipt(
            policy="explicit",
            selected_seat_ids=selected,
            eligible_seat_ids=selected,
            selection_reasons={seat_id: ["explicit_selection"] for seat_id in selected},
            task_profile=self.classify(objective),
            provider_families=sorted({self._family(seat) for seat in seats}),
            independence_groups=sorted({self._independence(seat) for seat in seats}),
            objective_sha256=hashlib.sha256(objective.encode("utf-8")).hexdigest(),
        )
