from __future__ import annotations

import asyncio
import json
import math
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable

from .providers import ProviderCompletion


class RunControlError(RuntimeError):
    """Base class for run-wide controls that seat-level error handling must not swallow."""


class BudgetExceeded(RunControlError):
    pass


class DeadlineExceeded(RunControlError):
    pass


class RunCancelled(RunControlError):
    def __init__(self, reason: str = "operator cancellation requested") -> None:
        super().__init__(reason)
        self.reason = reason


class UncertainCallError(RunControlError):
    """A provider attempt may have been accepted or billed, so automatic replay is unsafe."""


class ProviderCircuitOpen(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class BudgetPolicy:
    max_calls: int = 24
    max_input_tokens: int = 60_000
    max_output_tokens: int = 16_000
    max_estimated_cost_usd: float = 1.0
    max_output_tokens_per_call: int = 512
    deadline_seconds: float = 300.0
    request_timeout_seconds: float = 60.0
    retry_limit: int = 1
    retry_backoff_seconds: float = 0.25
    circuit_failure_threshold: int = 2
    circuit_cooldown_seconds: float = 60.0
    default_provider_concurrency: int = 2
    provider_concurrency: dict[str, int] = field(default_factory=dict)
    require_pricing: bool = True

    def __post_init__(self) -> None:
        integer_values = {
            "max_calls": self.max_calls,
            "max_input_tokens": self.max_input_tokens,
            "max_output_tokens": self.max_output_tokens,
            "max_output_tokens_per_call": self.max_output_tokens_per_call,
            "circuit_failure_threshold": self.circuit_failure_threshold,
            "default_provider_concurrency": self.default_provider_concurrency,
        }
        for name, value in integer_values.items():
            if value <= 0:
                raise ValueError(f"{name} must be positive")
        if self.max_estimated_cost_usd < 0:
            raise ValueError("max_estimated_cost_usd must not be negative")
        if self.deadline_seconds <= 0 or self.request_timeout_seconds <= 0:
            raise ValueError("deadline and request timeout must be positive")
        if self.retry_limit < 0 or self.retry_limit > 10:
            raise ValueError("retry_limit must be between 0 and 10")
        if self.retry_backoff_seconds < 0:
            raise ValueError("retry_backoff_seconds must not be negative")
        if self.circuit_cooldown_seconds < 0:
            raise ValueError("circuit_cooldown_seconds must not be negative")
        if any(value <= 0 for value in self.provider_concurrency.values()):
            raise ValueError("provider concurrency values must be positive")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "BudgetPolicy":
        return cls(**dict(data or {}))


@dataclass(frozen=True, slots=True)
class PricingRate:
    provider: str
    model: str
    input_usd_per_million: float
    output_usd_per_million: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PricingRate":
        rate = cls(
            provider=str(data["provider"]).strip().lower(),
            model=str(data["model"]).strip(),
            input_usd_per_million=float(data["input_usd_per_million"]),
            output_usd_per_million=float(data["output_usd_per_million"]),
        )
        if not rate.provider or not rate.model:
            raise ValueError("pricing provider and model must be non-empty")
        if rate.input_usd_per_million < 0 or rate.output_usd_per_million < 0:
            raise ValueError("pricing rates must not be negative")
        return rate


@dataclass(slots=True)
class CostTable:
    rates: list[PricingRate] = field(default_factory=list)
    free_providers: set[str] = field(default_factory=lambda: {"fake", "ollama"})

    @classmethod
    def load(cls, path: str | Path) -> "CostTable":
        with Path(path).open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            raise ValueError("pricing file must contain a JSON object")
        return cls(
            rates=[PricingRate.from_dict(item) for item in data.get("rates", [])],
            free_providers={str(item).strip().lower() for item in data.get("free_providers", ["ollama"])},
        )

    def rate_for(self, provider: str, model: str) -> PricingRate | None:
        normalized = provider.strip().lower()
        exact = next((item for item in self.rates if item.provider == normalized and item.model == model), None)
        if exact is not None:
            return exact
        return next((item for item in self.rates if item.provider == normalized and item.model == "*"), None)

    def is_free(self, provider: str) -> bool:
        return provider.strip().lower() in self.free_providers

    def estimate(self, provider: str, model: str, input_tokens: int, output_tokens: int) -> float | None:
        if self.is_free(provider):
            return 0.0
        rate = self.rate_for(provider, model)
        if rate is None:
            return None
        return round(
            input_tokens * rate.input_usd_per_million / 1_000_000
            + output_tokens * rate.output_usd_per_million / 1_000_000,
            8,
        )


def estimate_tokens(text: str) -> int:
    """Conservative tokenizer-independent estimate used only for hard reservations."""

    return max(1, math.ceil(len(text.encode("utf-8")) / 3))


@dataclass(slots=True)
class CallRecord:
    call_id: str
    provider: str
    model: str
    seat_id: str
    phase: str
    attempt: int
    status: str
    started_at: float
    input_tokens_reserved: int
    output_tokens_reserved: int
    estimated_cost_usd_reserved: float
    completed_at: float | None = None
    input_tokens_observed: int | None = None
    cached_input_tokens_observed: int | None = None
    output_tokens_observed: int = 0
    usage_source: str = "estimated"
    error_type: str | None = None
    retryable: bool | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CallRecord":
        return cls(**data)


@dataclass(slots=True)
class CircuitState:
    consecutive_failures: int = 0
    opened_at: float | None = None
    last_error_type: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CircuitState":
        return cls(**data)


@dataclass(slots=True)
class ExecutionLedger:
    started_at: float = field(default_factory=time.time)
    next_sequence: int = 1
    calls_started: int = 0
    calls_completed: int = 0
    calls_failed: int = 0
    input_tokens_reserved: int = 0
    input_tokens_observed: int = 0
    cached_input_tokens_observed: int = 0
    output_tokens_reserved: int = 0
    output_tokens_observed: int = 0
    estimated_cost_usd_reserved: float = 0.0
    budget_exceeded_reason: str | None = None
    calls: list[CallRecord] = field(default_factory=list)
    circuits: dict[str, CircuitState] = field(default_factory=dict)

    @property
    def uncertain_calls(self) -> list[CallRecord]:
        return [item for item in self.calls if item.status in {"started", "uncertain"}]

    @property
    def replay_blocking_calls(self) -> list[CallRecord]:
        """Attempts whose response cannot safely be issued again after restart."""

        return [
            item
            for item in self.calls
            if item.status in {"started", "uncertain", "completed_overrun"}
        ]

    def to_dict(self) -> dict[str, Any]:
        return {
            "started_at": self.started_at,
            "next_sequence": self.next_sequence,
            "calls_started": self.calls_started,
            "calls_completed": self.calls_completed,
            "calls_failed": self.calls_failed,
            "input_tokens_reserved": self.input_tokens_reserved,
            "input_tokens_observed": self.input_tokens_observed,
            "cached_input_tokens_observed": self.cached_input_tokens_observed,
            "output_tokens_reserved": self.output_tokens_reserved,
            "output_tokens_observed": self.output_tokens_observed,
            "estimated_cost_usd_reserved": self.estimated_cost_usd_reserved,
            "budget_exceeded_reason": self.budget_exceeded_reason,
            "calls": [item.to_dict() for item in self.calls],
            "circuits": {name: item.to_dict() for name, item in self.circuits.items()},
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "ExecutionLedger":
        values = dict(data or {})
        return cls(
            started_at=float(values.get("started_at", time.time())),
            next_sequence=int(values.get("next_sequence", 1)),
            calls_started=int(values.get("calls_started", 0)),
            calls_completed=int(values.get("calls_completed", 0)),
            calls_failed=int(values.get("calls_failed", 0)),
            input_tokens_reserved=int(values.get("input_tokens_reserved", 0)),
            input_tokens_observed=int(values.get("input_tokens_observed", 0)),
            cached_input_tokens_observed=int(values.get("cached_input_tokens_observed", 0)),
            output_tokens_reserved=int(values.get("output_tokens_reserved", 0)),
            output_tokens_observed=int(values.get("output_tokens_observed", 0)),
            estimated_cost_usd_reserved=float(values.get("estimated_cost_usd_reserved", 0.0)),
            budget_exceeded_reason=values.get("budget_exceeded_reason"),
            calls=[CallRecord.from_dict(item) for item in values.get("calls", [])],
            circuits={name: CircuitState.from_dict(item) for name, item in values.get("circuits", {}).items()},
        )


class RunController:
    def __init__(
        self,
        *,
        policy: BudgetPolicy,
        ledger: ExecutionLedger,
        costs: CostTable,
        persist: Callable[[], None],
        cancellation: Callable[[], tuple[bool, str | None]],
    ) -> None:
        self.policy = policy
        self.ledger = ledger
        self.costs = costs
        self.persist = persist
        self.cancellation = cancellation
        self._semaphores: dict[str, asyncio.Semaphore] = {}

    def assert_resume_safe(self) -> None:
        replay_blocking = self.ledger.replay_blocking_calls
        if replay_blocking:
            identifiers = ", ".join(item.call_id for item in replay_blocking)
            raise UncertainCallError(
                "automatic replay blocked because provider output is uncertain or was not "
                f"checkpointed inside its budget envelope: {identifiers}"
            )

    def _check_cancellation(self) -> None:
        requested, reason = self.cancellation()
        if requested:
            raise RunCancelled(reason or "operator cancellation requested")

    def _remaining_deadline(self) -> float:
        remaining = self.policy.deadline_seconds - (time.time() - self.ledger.started_at)
        if remaining <= 0:
            raise DeadlineExceeded("run deadline exhausted before the next provider attempt")
        return remaining

    def _check_circuit(self, provider: str) -> None:
        circuit = self.ledger.circuits.setdefault(provider, CircuitState())
        if circuit.opened_at is None:
            return
        elapsed = time.time() - circuit.opened_at
        if elapsed < self.policy.circuit_cooldown_seconds:
            raise ProviderCircuitOpen(
                f"provider circuit is open for {provider}; cooldown has {self.policy.circuit_cooldown_seconds - elapsed:.2f}s remaining"
            )
        circuit.opened_at = None

    def _reserve(
        self,
        *,
        provider: str,
        model: str,
        seat_id: str,
        phase: str,
        attempt: int,
        prompt: str,
        max_output_tokens: int,
    ) -> CallRecord:
        if self.ledger.budget_exceeded_reason:
            raise BudgetExceeded(self.ledger.budget_exceeded_reason)
        input_tokens = estimate_tokens(prompt)
        cost = self.costs.estimate(provider, model, input_tokens, max_output_tokens)
        if cost is None:
            if self.policy.require_pricing:
                raise BudgetExceeded(
                    f"live call blocked because pricing is not configured for provider={provider} model={model}"
                )
            cost = 0.0
        if self.ledger.calls_started + 1 > self.policy.max_calls:
            raise BudgetExceeded("maximum provider-call budget exhausted")
        if self.ledger.input_tokens_reserved + input_tokens > self.policy.max_input_tokens:
            raise BudgetExceeded("maximum input-token budget exhausted")
        if self.ledger.output_tokens_reserved + max_output_tokens > self.policy.max_output_tokens:
            raise BudgetExceeded("maximum output-token budget exhausted")
        if self.ledger.estimated_cost_usd_reserved + cost > self.policy.max_estimated_cost_usd + 1e-9:
            raise BudgetExceeded("maximum estimated-cost budget exhausted")
        call_id = f"call_{self.ledger.next_sequence:06d}"
        self.ledger.next_sequence += 1
        record = CallRecord(
            call_id=call_id,
            provider=provider,
            model=model,
            seat_id=seat_id,
            phase=phase,
            attempt=attempt,
            status="started",
            started_at=time.time(),
            input_tokens_reserved=input_tokens,
            output_tokens_reserved=max_output_tokens,
            estimated_cost_usd_reserved=cost,
        )
        self.ledger.calls.append(record)
        self.ledger.calls_started += 1
        self.ledger.input_tokens_reserved += input_tokens
        self.ledger.output_tokens_reserved += max_output_tokens
        self.ledger.estimated_cost_usd_reserved = round(self.ledger.estimated_cost_usd_reserved + cost, 8)
        self.persist()
        return record

    def _record_success(
        self,
        record: CallRecord,
        output: str,
        completion: ProviderCompletion | None = None,
    ) -> None:
        observed = (
            completion.output_tokens
            if completion is not None and completion.output_tokens is not None
            else estimate_tokens(output)
        )
        input_observed = completion.input_tokens if completion is not None else None
        cached_observed = completion.cached_input_tokens if completion is not None else None
        output_overrun = (
            observed > record.output_tokens_reserved
            or self.ledger.output_tokens_observed + observed > self.policy.max_output_tokens
        )
        input_overrun = (
            input_observed is not None
            and self.ledger.input_tokens_observed + input_observed > self.policy.max_input_tokens
        )
        overrun = output_overrun or input_overrun
        record.status = "completed_overrun" if overrun else "completed"
        record.completed_at = time.time()
        record.input_tokens_observed = input_observed
        record.cached_input_tokens_observed = cached_observed
        record.output_tokens_observed = observed
        record.usage_source = completion.usage_source if completion is not None else "estimated"
        self.ledger.calls_completed += 1
        if input_observed is not None:
            self.ledger.input_tokens_observed += input_observed
        if cached_observed is not None:
            self.ledger.cached_input_tokens_observed += cached_observed
        self.ledger.output_tokens_observed += observed
        circuit = self.ledger.circuits.setdefault(record.provider, CircuitState())
        circuit.consecutive_failures = 0
        circuit.opened_at = None
        circuit.last_error_type = None
        if overrun:
            dimension = "input" if input_overrun else "output"
            self.ledger.budget_exceeded_reason = (
                f"provider attempt {record.call_id} exceeded its reserved {dimension}-token envelope"
            )
        self.persist()
        if overrun:
            raise BudgetExceeded(
                self.ledger.budget_exceeded_reason
                or f"provider attempt {record.call_id} exceeded its token envelope"
            )

    def _record_failure(self, record: CallRecord, exc: BaseException, *, uncertain: bool) -> None:
        record.status = "uncertain" if uncertain else "failed"
        record.completed_at = time.time()
        record.error_type = type(exc).__name__
        record.retryable = bool(getattr(exc, "retryable", False))
        self.ledger.calls_failed += 1
        circuit = self.ledger.circuits.setdefault(record.provider, CircuitState())
        circuit.consecutive_failures += 1
        circuit.last_error_type = type(exc).__name__
        if circuit.consecutive_failures >= self.policy.circuit_failure_threshold:
            circuit.opened_at = time.time()
        self.persist()

    async def execute_attempt(
        self,
        *,
        provider: str,
        model: str,
        seat_id: str,
        phase: str,
        attempt: int,
        prompt: str,
        max_output_tokens: int,
        operation: Callable[[], Awaitable[str | ProviderCompletion]],
    ) -> str:
        limit = self.policy.provider_concurrency.get(provider, self.policy.default_provider_concurrency)
        semaphore = self._semaphores.setdefault(provider, asyncio.Semaphore(limit))
        async with semaphore:
            self._check_cancellation()
            remaining_deadline = self._remaining_deadline()
            self._check_circuit(provider)
            record = self._reserve(
                provider=provider,
                model=model,
                seat_id=seat_id,
                phase=phase,
                attempt=attempt,
                prompt=prompt,
                max_output_tokens=max_output_tokens,
            )
            try:
                output = await asyncio.wait_for(
                    operation(),
                    timeout=min(self.policy.request_timeout_seconds, remaining_deadline),
                )
            except TimeoutError as exc:
                self._record_failure(record, exc, uncertain=True)
                raise UncertainCallError(
                    f"provider attempt {record.call_id} timed out; outcome may be accepted or billable and will not be replayed"
                ) from exc
            except asyncio.CancelledError as exc:
                self._record_failure(record, exc, uncertain=True)
                raise UncertainCallError(
                    f"provider attempt {record.call_id} was interrupted; outcome is uncertain and will not be replayed"
                ) from exc
            except Exception as exc:
                self._record_failure(record, exc, uncertain=False)
                raise
            completion = output if isinstance(output, ProviderCompletion) else None
            text = completion.text if completion is not None else output
            if not isinstance(text, str):
                exc = TypeError("provider operation must return text")
                self._record_failure(record, exc, uncertain=False)
                raise exc
            self._record_success(record, text, completion)
            return text
