from __future__ import annotations

import asyncio
import hashlib
import importlib
import importlib.resources
import json
import os
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable, Literal, Protocol
from urllib.parse import urlsplit

from .models import CapabilityResult


CAPABILITY_ID_PATTERN = re.compile(r"^echo\.[a-z0-9_.-]{1,126}[a-z0-9]$")
_SENSITIVE_KEY_PATTERN = re.compile(
    r"(?:api[_-]?key|authorization|cookie|credential|password|private[_-]?key|secret|session|token)",
    re.IGNORECASE,
)
_INLINE_SECRET_PATTERNS = (
    re.compile(r"(?i)(bearer\s+)[A-Za-z0-9._~+/=-]{8,}"),
    re.compile(r"(?i)\bsk-[A-Za-z0-9_-]{8,}\b"),
    re.compile(r"(?i)((?:api[_-]?key|password|secret|token)\s*[:=]\s*)[^\s,;]+"),
)


class CapabilityError(RuntimeError):
    def __init__(
        self,
        code: str,
        message: str,
        *,
        status: Literal["unauthorized", "unavailable", "failed"] = "failed",
        retryable: bool = False,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.status = status
        self.retryable = retryable


@dataclass(slots=True, frozen=True)
class CapabilitySpec:
    capability_id: str
    description: str
    adapter: str = "echo_sdk"
    params: dict[str, Any] = field(default_factory=dict)
    trigger_terms: tuple[str, ...] = ()
    always: bool = False
    required_scope: str = "tier:0"
    danger_tier: int = 0
    read_only: bool = True
    timeout_seconds: float = 20.0
    max_payload_chars: int = 12_000
    source_kind: str = "sdk"

    def __post_init__(self) -> None:
        if not CAPABILITY_ID_PATTERN.fullmatch(self.capability_id):
            raise ValueError(f"invalid Echo capability id: {self.capability_id!r}")
        if not self.description.strip():
            raise ValueError(f"capability {self.capability_id} has no description")
        if not self.adapter.strip():
            raise ValueError(f"capability {self.capability_id} has no adapter")
        if not 0 <= self.danger_tier <= 3:
            raise ValueError(f"capability {self.capability_id} has an invalid danger tier")
        if not 0.1 <= self.timeout_seconds <= 120:
            raise ValueError(f"capability {self.capability_id} timeout is outside 0.1..120 seconds")
        if not 256 <= self.max_payload_chars <= 100_000:
            raise ValueError(f"capability {self.capability_id} payload bound is outside 256..100000")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CapabilitySpec":
        return cls(
            capability_id=str(data.get("id") or data.get("capability_id") or ""),
            description=str(data.get("description") or ""),
            adapter=str(data.get("adapter") or "echo_sdk"),
            params=dict(data.get("params") or {}),
            trigger_terms=tuple(
                str(item).strip().lower()
                for item in data.get("trigger_terms", [])
                if str(item).strip()
            ),
            always=bool(data.get("always", False)),
            required_scope=str(data.get("required_scope") or "tier:0"),
            danger_tier=int(data.get("danger_tier", 0)),
            read_only=bool(data.get("read_only", True)),
            timeout_seconds=float(data.get("timeout_seconds", 20.0)),
            max_payload_chars=int(data.get("max_payload_chars", 12_000)),
            source_kind=str(data.get("source_kind") or "sdk"),
        )

    def applicable(self, objective: str) -> bool:
        if self.always:
            return True
        lowered = objective.lower()
        return any(term in lowered for term in self.trigger_terms)

    def rendered_params(self, objective: str) -> dict[str, Any]:
        def render(value: Any) -> Any:
            if value == "$objective":
                return objective
            if isinstance(value, dict):
                return {str(key): render(item) for key, item in value.items()}
            if isinstance(value, list):
                return [render(item) for item in value]
            return value

        return render(self.params)


@dataclass(slots=True, frozen=True)
class CapabilityRequest:
    run_id: str
    objective: str
    spec: CapabilitySpec
    params: dict[str, Any]


@dataclass(slots=True, frozen=True)
class CapabilityReadiness:
    capability_id: str
    status: Literal["ready", "unauthorized", "misconfigured", "unavailable"]
    network_verified: bool = False
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "capability_id": self.capability_id,
            "status": self.status,
            "network_verified": self.network_verified,
            "reason": self.reason,
        }


class CapabilityAdapter(Protocol):
    async def readiness(self, spec: CapabilitySpec) -> CapabilityReadiness: ...

    async def invoke(self, request: CapabilityRequest) -> Any: ...


class CallableCapabilityAdapter:
    """Host adapter for an already-authorized SDK client or MCP connection."""

    def __init__(
        self,
        callback: Callable[[CapabilityRequest], Awaitable[Any] | Any],
        *,
        readiness_callback: Callable[
            [CapabilitySpec], Awaitable[CapabilityReadiness] | CapabilityReadiness
        ]
        | None = None,
    ) -> None:
        self.callback = callback
        self.readiness_callback = readiness_callback

    async def readiness(self, spec: CapabilitySpec) -> CapabilityReadiness:
        if self.readiness_callback is None:
            return CapabilityReadiness(
                spec.capability_id,
                "ready",
                network_verified=False,
                reason="host adapter configured; network verification deferred to invocation",
            )
        response = self.readiness_callback(spec)
        return await response if asyncio.iscoroutine(response) else response

    async def invoke(self, request: CapabilityRequest) -> Any:
        response = self.callback(request)
        return await response if asyncio.iscoroutine(response) else response


class DeterministicFakeCapabilityAdapter:
    """Explicit test instrument; never registered as an implicit live fallback."""

    def __init__(self) -> None:
        self.calls: list[CapabilityRequest] = []

    async def readiness(self, spec: CapabilitySpec) -> CapabilityReadiness:
        return CapabilityReadiness(
            spec.capability_id,
            "ready",
            network_verified=True,
            reason="deterministic test adapter",
        )

    async def invoke(self, request: CapabilityRequest) -> Any:
        self.calls.append(request)
        capability_id = request.spec.capability_id
        if capability_id.startswith("echo.wolfram."):
            return {
                "answer": "deterministic computational evidence",
                "query": request.objective,
                "sources": ["sdk://echo.wolfram"],
            }
        if capability_id == "echo.arcanum.search":
            return {
                "matches": [
                    {
                        "id": "deterministic-arcanum-pattern",
                        "title": "evidence-first decomposition",
                    }
                ]
            }
        if capability_id == "echo.knowledge.search":
            return {
                "hits": [
                    {
                        "document_id": "deterministic-knowledge",
                        "snippet": "bounded provenance-bearing knowledge evidence",
                        "score": 1.0,
                    }
                ]
            }
        return {
            "capability": capability_id,
            "status": "deterministic",
            "objective_sha256": hashlib.sha256(request.objective.encode("utf-8")).hexdigest(),
        }


class EchoSDKCapabilityAdapter:
    """Standard-library Echo SDK client with runtime-only credential resolution."""

    def __init__(
        self,
        base_url: str,
        *,
        api_key_env: str = "ECHO_SDK_API_KEY",
        api_key_loader: Callable[[], str] | None = None,
        user_agent: str = "maximalist-reconstructed-capabilities/0.4",
    ) -> None:
        parsed = urlsplit(base_url.strip())
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            raise ValueError("Echo SDK base URL must be an absolute http(s) URL")
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("Echo SDK base URL must not contain credentials, query, or fragment")
        self.base_url = base_url.strip().rstrip("/")
        self.api_key_env = api_key_env.strip()
        self.api_key_loader = api_key_loader
        self.user_agent = user_agent

    def _load_key(self) -> str:
        value = self.api_key_loader() if self.api_key_loader else os.environ.get(self.api_key_env, "")
        value = str(value or "").strip()
        if not value:
            raise CapabilityError(
                "credential_unavailable",
                "Echo SDK credential is unavailable",
                status="unauthorized",
            )
        return value

    async def readiness(self, spec: CapabilitySpec) -> CapabilityReadiness:
        try:
            self._load_key()
        except CapabilityError:
            return CapabilityReadiness(
                spec.capability_id,
                "unauthorized",
                network_verified=False,
                reason="runtime credential reference did not resolve",
            )
        return CapabilityReadiness(
            spec.capability_id,
            "ready",
            network_verified=False,
            reason="configured; live round-trip deferred to bounded invocation",
        )

    def _invoke_sync(self, request: CapabilityRequest) -> Any:
        body = json.dumps(
            {
                "envelope_version": 1,
                "capability": request.spec.capability_id,
                "params": request.params,
            },
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
        message = urllib.request.Request(
            f"{self.base_url}/sdk/invoke",
            data=body,
            method="POST",
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": self.user_agent,
                "X-Echo-API-Key": self._load_key(),
            },
        )
        try:
            with urllib.request.urlopen(message, timeout=request.spec.timeout_seconds) as response:
                raw = response.read(1_000_001)
        except urllib.error.HTTPError as exc:
            if exc.code in {401, 403}:
                raise CapabilityError(
                    "scope_or_auth_denied",
                    "Echo SDK denied the capability scope",
                    status="unauthorized",
                ) from exc
            if exc.code == 404:
                raise CapabilityError(
                    "capability_unavailable",
                    "Echo SDK capability is not registered at the selected gate",
                    status="unavailable",
                ) from exc
            raise CapabilityError(
                "sdk_http_error",
                f"Echo SDK request failed with HTTP {exc.code}",
                status="unavailable" if exc.code >= 500 else "failed",
                retryable=exc.code >= 500,
            ) from exc
        except urllib.error.URLError as exc:
            raise CapabilityError(
                "sdk_unreachable",
                "Echo SDK gate is unreachable",
                status="unavailable",
                retryable=True,
            ) from exc
        if len(raw) > 1_000_000:
            raise CapabilityError("response_too_large", "Echo SDK response exceeded 1 MiB")
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise CapabilityError("invalid_json", "Echo SDK returned invalid JSON") from exc
        if isinstance(payload, dict) and (
            payload.get("ok") is False
            or payload.get("status") not in {None, "ok", "success"}
        ):
            error = payload.get("error") or payload.get("detail")
            message = str(error if isinstance(error, str) else "Echo SDK rejected the capability call")
            raise CapabilityError("sdk_rejected", _redact_string(message)[:500])
        return payload

    async def invoke(self, request: CapabilityRequest) -> Any:
        return await asyncio.to_thread(self._invoke_sync, request)


class CapabilityAdapterRegistry:
    def __init__(self) -> None:
        self._adapters: dict[str, CapabilityAdapter] = {}

    def register(self, name: str, adapter: CapabilityAdapter) -> None:
        normalized = name.strip().lower()
        if not normalized:
            raise ValueError("capability adapter name must not be empty")
        self._adapters[normalized] = adapter

    def get(self, name: str) -> CapabilityAdapter | None:
        return self._adapters.get(name.strip().lower())


@dataclass(slots=True)
class CapabilityCatalog:
    specs: dict[str, CapabilitySpec]
    profiles: dict[str, list[str]]
    schema_version: int = 1

    @classmethod
    def load(cls, path: str | Path | None = None) -> "CapabilityCatalog":
        if path is not None:
            with Path(path).open("r", encoding="utf-8") as handle:
                data = json.load(handle)
        else:
            resource = importlib.resources.files(__package__).joinpath("capabilities.json")
            data = json.loads(resource.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("capability catalog must be a JSON object")
        specs: dict[str, CapabilitySpec] = {}
        for item in data.get("capabilities", []):
            if not isinstance(item, dict):
                raise ValueError("each capability catalog entry must be an object")
            spec = CapabilitySpec.from_dict(item)
            if spec.capability_id in specs:
                raise ValueError(f"duplicate capability id: {spec.capability_id}")
            specs[spec.capability_id] = spec
        profiles = {
            str(name): [str(capability_id) for capability_id in identifiers]
            for name, identifiers in dict(data.get("profiles") or {}).items()
        }
        profiles.setdefault("off", [])
        for name, identifiers in profiles.items():
            unknown = sorted(set(identifiers) - set(specs))
            if unknown:
                raise ValueError(f"capability profile {name!r} references unknown ids: {unknown}")
        return cls(
            specs=specs,
            profiles=profiles,
            schema_version=int(data.get("schema_version", 1)),
        )

    def select(
        self,
        profile: str,
        explicit_ids: list[str] | None = None,
    ) -> list[CapabilitySpec]:
        if profile not in self.profiles:
            raise ValueError(
                f"unknown capability profile {profile!r}; available profiles: {sorted(self.profiles)}"
            )
        identifiers = list(self.profiles[profile])
        identifiers.extend(explicit_ids or [])
        identifiers = list(dict.fromkeys(identifiers))
        unknown = sorted(set(identifiers) - set(self.specs))
        if unknown:
            raise ValueError(f"unknown configured capability ids: {unknown}")
        selected = [self.specs[capability_id] for capability_id in identifiers]
        unsafe = [
            spec.capability_id
            for spec in selected
            if not spec.read_only or spec.danger_tier > 1
        ]
        if unsafe:
            raise ValueError(
                "Fusion grounding accepts only explicitly read-only tier 0-1 capabilities: "
                f"{unsafe}"
            )
        return selected


class CapabilityOrchestrator:
    def __init__(
        self,
        *,
        profile: str,
        specs: list[CapabilitySpec],
        adapters: CapabilityAdapterRegistry,
        mode: Literal["disabled", "deterministic_test", "live"],
        max_calls: int = 12,
        max_concurrency: int = 4,
    ) -> None:
        if not 0 <= max_calls <= 64:
            raise ValueError("capability max_calls must be between 0 and 64")
        if not 1 <= max_concurrency <= 16:
            raise ValueError("capability max_concurrency must be between 1 and 16")
        self.profile = profile
        self.specs = list(specs)
        self.adapters = adapters
        self.mode = mode
        self.max_calls = max_calls
        self.max_concurrency = max_concurrency

    @property
    def selected_ids(self) -> list[str]:
        return [spec.capability_id for spec in self.specs]

    async def preflight(self) -> dict[str, Any]:
        readiness: list[CapabilityReadiness] = []
        for spec in self.specs:
            adapter = self.adapters.get(spec.adapter)
            if adapter is None:
                readiness.append(
                    CapabilityReadiness(
                        spec.capability_id,
                        "misconfigured",
                        reason=f"adapter {spec.adapter!r} is not registered",
                    )
                )
                continue
            try:
                readiness.append(await adapter.readiness(spec))
            except Exception as exc:
                readiness.append(
                    CapabilityReadiness(
                        spec.capability_id,
                        "unavailable",
                        reason=_safe_error(exc),
                    )
                )
        return {
            "profile": self.profile,
            "mode": self.mode,
            "selected_capability_ids": self.selected_ids,
            "ready_capability_ids": [
                item.capability_id for item in readiness if item.status == "ready"
            ],
            "capabilities": [item.to_dict() for item in readiness],
            "credential_values_exposed": False,
        }

    async def gather(self, *, run_id: str, objective: str) -> list[CapabilityResult]:
        applicable: list[CapabilitySpec] = []
        skipped: list[CapabilityResult] = []
        for spec in self.specs:
            if spec.applicable(objective):
                applicable.append(spec)
            else:
                skipped.append(
                    CapabilityResult(
                        capability_id=spec.capability_id,
                        status="skipped",
                        required_scope=spec.required_scope,
                        danger_tier=spec.danger_tier,
                        read_only=spec.read_only,
                        error="objective did not match the configured trigger terms",
                    )
                )
        over_budget = applicable[self.max_calls :]
        applicable = applicable[: self.max_calls]
        skipped.extend(
            CapabilityResult(
                capability_id=spec.capability_id,
                status="skipped",
                required_scope=spec.required_scope,
                danger_tier=spec.danger_tier,
                read_only=spec.read_only,
                error="capability call budget exhausted before invocation",
            )
            for spec in over_budget
        )
        semaphore = asyncio.Semaphore(self.max_concurrency)

        async def execute(spec: CapabilitySpec) -> CapabilityResult:
            started = time.perf_counter()
            adapter = self.adapters.get(spec.adapter)
            if adapter is None:
                return CapabilityResult(
                    capability_id=spec.capability_id,
                    status="unavailable",
                    required_scope=spec.required_scope,
                    danger_tier=spec.danger_tier,
                    read_only=spec.read_only,
                    error=f"capability adapter {spec.adapter!r} is not registered",
                )
            request = CapabilityRequest(
                run_id=run_id,
                objective=objective,
                spec=spec,
                params=spec.rendered_params(objective),
            )
            try:
                async with semaphore:
                    raw = await asyncio.wait_for(
                        adapter.invoke(request), timeout=spec.timeout_seconds + 0.5
                    )
                payload, truncated = _bounded_payload(raw, spec.max_payload_chars)
                canonical = json.dumps(
                    payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
                )
                return CapabilityResult(
                    capability_id=spec.capability_id,
                    status="completed",
                    payload=payload,
                    source_refs=[f"{spec.source_kind}://{spec.capability_id}"],
                    required_scope=spec.required_scope,
                    danger_tier=spec.danger_tier,
                    read_only=spec.read_only,
                    latency_ms=int((time.perf_counter() - started) * 1000),
                    payload_sha256=hashlib.sha256(canonical.encode("utf-8")).hexdigest(),
                    truncated=truncated,
                )
            except asyncio.TimeoutError:
                return CapabilityResult(
                    capability_id=spec.capability_id,
                    status="timed_out",
                    required_scope=spec.required_scope,
                    danger_tier=spec.danger_tier,
                    read_only=spec.read_only,
                    latency_ms=int((time.perf_counter() - started) * 1000),
                    error="bounded capability invocation timed out",
                )
            except CapabilityError as exc:
                return CapabilityResult(
                    capability_id=spec.capability_id,
                    status=exc.status,
                    required_scope=spec.required_scope,
                    danger_tier=spec.danger_tier,
                    read_only=spec.read_only,
                    latency_ms=int((time.perf_counter() - started) * 1000),
                    error=f"{exc.code}: {_safe_error(exc)}",
                )
            except Exception as exc:
                return CapabilityResult(
                    capability_id=spec.capability_id,
                    status="failed",
                    required_scope=spec.required_scope,
                    danger_tier=spec.danger_tier,
                    read_only=spec.read_only,
                    latency_ms=int((time.perf_counter() - started) * 1000),
                    error=_safe_error(exc),
                )

        completed = await asyncio.gather(*(execute(spec) for spec in applicable))
        by_id = {item.capability_id: item for item in [*completed, *skipped]}
        return [by_id[spec.capability_id] for spec in self.specs if spec.capability_id in by_id]


def build_deterministic_capability_orchestrator(
    catalog: CapabilityCatalog,
    profile: str,
    *,
    explicit_ids: list[str] | None = None,
    max_calls: int = 12,
) -> tuple[CapabilityOrchestrator, DeterministicFakeCapabilityAdapter]:
    fake = DeterministicFakeCapabilityAdapter()
    adapters = CapabilityAdapterRegistry()
    adapters.register("echo_sdk", fake)
    return (
        CapabilityOrchestrator(
            profile=profile,
            specs=catalog.select(profile, explicit_ids),
            adapters=adapters,
            mode="deterministic_test" if profile != "off" or explicit_ids else "disabled",
            max_calls=max_calls,
        ),
        fake,
    )


def build_live_capability_orchestrator(
    catalog: CapabilityCatalog,
    profile: str,
    *,
    adapter: CapabilityAdapter,
    explicit_ids: list[str] | None = None,
    max_calls: int = 12,
) -> CapabilityOrchestrator:
    adapters = CapabilityAdapterRegistry()
    adapters.register("echo_sdk", adapter)
    return CapabilityOrchestrator(
        profile=profile,
        specs=catalog.select(profile, explicit_ids),
        adapters=adapters,
        mode="live" if profile != "off" or explicit_ids else "disabled",
        max_calls=max_calls,
    )


def load_capability_adapter_factory(reference: str) -> CapabilityAdapter:
    module_name, separator, attribute = reference.partition(":")
    if not separator or not module_name or not attribute:
        raise ValueError("capability adapter factory must use MODULE:CALLABLE syntax")
    module = importlib.import_module(module_name)
    factory = getattr(module, attribute)
    adapter = factory()
    if not callable(getattr(adapter, "invoke", None)) or not callable(
        getattr(adapter, "readiness", None)
    ):
        raise TypeError("capability adapter factory did not return a compatible adapter")
    return adapter


def _redact_string(value: str) -> str:
    redacted = value
    for pattern in _INLINE_SECRET_PATTERNS:
        redacted = pattern.sub(r"\1[REDACTED]" if pattern.groups else "[REDACTED]", redacted)
    return redacted


def _redact_and_bound(value: Any, *, depth: int = 0) -> Any:
    if depth >= 8:
        return "[MAX_DEPTH]"
    if isinstance(value, dict):
        output: dict[str, Any] = {}
        for index, (key, item) in enumerate(value.items()):
            if index >= 100:
                output["_truncated_keys"] = True
                break
            name = str(key)[:200]
            output[name] = (
                "[REDACTED]"
                if _SENSITIVE_KEY_PATTERN.search(name)
                else _redact_and_bound(item, depth=depth + 1)
            )
        return output
    if isinstance(value, (list, tuple, set)):
        items = sorted(value, key=repr) if isinstance(value, set) else list(value)
        bounded = [_redact_and_bound(item, depth=depth + 1) for item in items[:100]]
        if len(items) > 100:
            bounded.append("[TRUNCATED_ITEMS]")
        return bounded
    if isinstance(value, str):
        return _redact_string(value)[:20_000]
    if value is None or isinstance(value, (bool, int, float)):
        return value
    return _redact_string(str(value))[:20_000]


def _bounded_payload(value: Any, max_chars: int) -> tuple[dict[str, Any], bool]:
    safe = _redact_and_bound(value)
    payload = safe if isinstance(safe, dict) else {"value": safe}
    rendered = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    if len(rendered) <= max_chars:
        return payload, False
    return {
        "bounded_excerpt": rendered[:max_chars],
        "original_redacted_chars": len(rendered),
    }, True


def _safe_error(exc: BaseException) -> str:
    return _redact_string(f"{type(exc).__name__}: {exc}")[:500]
