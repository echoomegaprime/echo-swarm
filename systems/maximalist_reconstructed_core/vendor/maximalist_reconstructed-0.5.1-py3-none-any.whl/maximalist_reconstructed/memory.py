from __future__ import annotations

import asyncio
import json
import os
import tempfile
from pathlib import Path
from typing import Any, Protocol

from .models import FusionResult


MAX_RETRIEVED_MEMORY_RECORDS = 3
MAX_MEMORY_OBJECTIVE_CHARS = 500
MAX_MEMORY_ANSWER_CHARS = 1_500
MAX_MEMORY_CLAIM_CHARS = 500
MAX_MEMORY_FINDINGS = 3
MAX_MEMORY_DISSENT = 2
MAX_MEMORY_UNRESOLVED = 3


def _text(value: Any, limit: int) -> str:
    return str(value or "")[:limit]


def _bounded_memory_record(record: dict[str, Any]) -> dict[str, Any]:
    """Project current or legacy records into a small model-context-safe shape."""
    findings: list[dict[str, Any]] = []
    for item in list(record.get("major_findings") or [])[:MAX_MEMORY_FINDINGS]:
        if not isinstance(item, dict):
            continue
        findings.append(
            {
                "claim": _text(item.get("claim"), MAX_MEMORY_CLAIM_CHARS),
                "topic": _text(item.get("topic"), 120),
                "stance": _text(item.get("stance"), 40),
                "confidence": item.get("confidence"),
            }
        )
    dissent: list[dict[str, Any]] = []
    for item in list(record.get("dissent") or [])[:MAX_MEMORY_DISSENT]:
        if not isinstance(item, dict):
            continue
        dissent.append(
            {
                "claim": _text(item.get("claim"), MAX_MEMORY_CLAIM_CHARS),
                "topic": _text(item.get("topic"), 120),
                "reason": _text(item.get("reason"), 300),
            }
        )
    return {
        "id": _text(record.get("id"), 200),
        "objective": _text(record.get("objective"), MAX_MEMORY_OBJECTIVE_CHARS),
        "answer": _text(record.get("answer"), MAX_MEMORY_ANSWER_CHARS),
        "confidence": record.get("confidence"),
        "major_findings": findings,
        "dissent": dissent,
        "unresolved": [
            _text(item, MAX_MEMORY_CLAIM_CHARS)
            for item in list(record.get("unresolved") or [])[:MAX_MEMORY_UNRESOLVED]
        ],
        "profile": _text(record.get("profile"), 100),
        "historical_parity": False,
    }


class MemoryAdapter(Protocol):
    async def retrieve(self, objective: str, limit: int = 20) -> list[dict[str, Any]]:
        ...

    async def write_run(self, result: FusionResult) -> list[str]:
        ...


class InMemoryMemoryAdapter:
    def __init__(self, seed: list[dict[str, Any]] | None = None) -> None:
        self.records: dict[str, dict[str, Any]] = {}
        self.seed = list(seed or [])
        self.write_attempts: list[str] = []

    async def retrieve(self, objective: str, limit: int = 20) -> list[dict[str, Any]]:
        persisted = list(self.records.values())
        return (self.seed + persisted)[-max(0, limit) :]

    async def write_run(self, result: FusionResult) -> list[str]:
        self.write_attempts.append(result.run_id)
        memory_id = f"run:{result.run_id}"
        self.records[result.run_id] = {
            "id": memory_id,
            "objective": result.provenance.get("objective", ""),
            "answer": result.answer,
            "confidence": result.confidence,
            "profile": result.provenance.get("profile"),
            "historical_parity": False,
        }
        return [memory_id]

class JsonFileMemoryAdapter:
    """Small idempotent local memory adapter keyed by run ID."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = asyncio.Lock()

    def _read(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"version": 1, "records": {}}
        with self.path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, dict) or not isinstance(data.get("records", {}), dict):
            raise ValueError("memory file has an invalid schema")
        return data

    def _atomic_write(self, data: dict[str, Any]) -> None:
        descriptor, temporary = tempfile.mkstemp(prefix=f".{self.path.name}.", suffix=".tmp", dir=self.path.parent)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
                json.dump(data, handle, indent=2, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    async def retrieve(self, objective: str, limit: int = 20) -> list[dict[str, Any]]:
        async with self._lock:
            data = await asyncio.to_thread(self._read)
        words = {word.lower() for word in objective.split() if len(word) > 3}
        records = list(data.get("records", {}).values())
        ranked = sorted(
            records,
            key=lambda item: sum(word in json.dumps(item).lower() for word in words),
            reverse=True,
        )
        selected = ranked[: min(max(0, limit), MAX_RETRIEVED_MEMORY_RECORDS)]
        return [_bounded_memory_record(item) for item in selected if isinstance(item, dict)]

    async def write_run(self, result: FusionResult) -> list[str]:
        memory_id = f"run:{result.run_id}"
        async with self._lock:
            data = await asyncio.to_thread(self._read)
            records = data.setdefault("records", {})
            records[result.run_id] = _bounded_memory_record({
                "id": memory_id,
                "objective": result.provenance.get("objective", ""),
                "answer": result.answer,
                "confidence": result.confidence,
                "major_findings": [item.to_dict() for item in result.major_findings],
                "dissent": [item.to_dict() for item in result.dissent],
                "unresolved": list(result.unresolved),
                "profile": result.provenance.get("profile"),
                "historical_parity": False,
            })
            await asyncio.to_thread(self._atomic_write, data)
        return [memory_id]
