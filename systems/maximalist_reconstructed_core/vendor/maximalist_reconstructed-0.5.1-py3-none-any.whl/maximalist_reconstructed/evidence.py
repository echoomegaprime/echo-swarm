from __future__ import annotations

import hashlib
import re
from collections import defaultdict
from typing import Iterable

from .config import SeatRegistry
from .models import (
    CapabilityResult,
    ClaimCluster,
    CoverageReport,
    Dissent,
    Finding,
    RankedFinding,
    SeatContribution,
    SeatResult,
)


def evidence_ledger_refs(
    capability_results: Iterable[CapabilityResult],
    memory_reads: Iterable[str],
) -> set[str]:
    refs = {str(item) for item in memory_reads if str(item)}
    for result in capability_results:
        if result.status != "completed":
            continue
        refs.add(f"capability:{result.capability_id}")
        refs.update(result.source_refs)
        if result.payload_sha256:
            refs.add(f"sha256:{result.payload_sha256}")
    return refs


def _topic_key(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()
    return normalized or "unclassified"


def build_claim_clusters(
    findings: list[Finding],
    registry: SeatRegistry,
    validated_refs: set[str],
) -> list[ClaimCluster]:
    seats = {seat.id: seat for seat in registry.enabled_seats}
    grouped: dict[str, list[Finding]] = defaultdict(list)
    for finding in findings:
        grouped[_topic_key(finding.topic or finding.claim)].append(finding)

    clusters: list[ClaimCluster] = []
    for topic_key, items in sorted(grouped.items()):
        supporting = [item for item in items if item.stance == "supports"]
        opposing = [item for item in items if item.stance == "opposes"]
        neutral = [item for item in items if item.stance == "neutral"]
        all_refs = sorted({ref for item in items for ref in item.source_refs})
        valid = sorted(set(all_refs).intersection(validated_refs))
        invalid = sorted(set(all_refs) - set(valid))

        def families(values: list[Finding]) -> set[str]:
            return {
                (seats[item.seat_id].provider_family or seats[item.seat_id].provider)
                if item.seat_id in seats
                else item.model
                for item in values
            }

        support_families = families(supporting)
        oppose_families = families(opposing)
        provider_families = sorted(families(items))
        independence_groups = sorted(
            {
                (seats[item.seat_id].independence_group
                 or seats[item.seat_id].provider_family
                 or seats[item.seat_id].provider)
                if item.seat_id in seats
                else item.model
                for item in items
            }
        )
        support_score = min(
            1.0,
            0.18 * len(support_families)
            + 0.12 * len(valid)
            + 0.08 * sum(1 for item in supporting if item.verified),
        )
        refutation_score = min(
            1.0,
            0.18 * len(oppose_families)
            + 0.12 * len(valid)
            + 0.08 * sum(1 for item in opposing if item.verified),
        )
        if supporting and opposing:
            status = "contested"
        elif supporting and (valid or any(item.verified for item in supporting)):
            status = "supported"
        elif opposing and (valid or any(item.verified for item in opposing)):
            status = "refuted"
        else:
            status = "unresolved"
        canonical = max(items, key=lambda item: (item.importance, item.confidence, item.claim)).claim
        cluster_id = "cluster:" + hashlib.sha256(topic_key.encode("utf-8")).hexdigest()[:20]
        clusters.append(
            ClaimCluster(
                cluster_id=cluster_id,
                topic=items[0].topic or topic_key,
                canonical_claim=canonical,
                supporting_finding_ids=sorted(item.finding_id for item in supporting),
                opposing_finding_ids=sorted(item.finding_id for item in opposing),
                neutral_finding_ids=sorted(item.finding_id for item in neutral),
                provider_families=provider_families,
                independence_groups=independence_groups,
                validated_source_refs=valid,
                unverified_source_refs=invalid,
                support_score=round(support_score, 6),
                refutation_score=round(refutation_score, 6),
                status=status,  # type: ignore[arg-type]
            )
        )
    return clusters


def build_seat_contributions(
    results: list[SeatResult],
    ranked: list[RankedFinding],
    dissent: list[Dissent],
    registry: SeatRegistry,
) -> list[SeatContribution]:
    selected_ids = {item.finding.finding_id for item in ranked[:20]}
    by_seat: dict[str, list[SeatResult]] = defaultdict(list)
    for result in results:
        by_seat[result.seat_id].append(result)
    contributions: list[SeatContribution] = []
    for seat_id, seat_results in sorted(by_seat.items()):
        try:
            seat = registry.get(seat_id)
            provider, model, role = seat.provider, seat.model, seat.role
        except KeyError:
            first = seat_results[0]
            provider, model, role = "unknown", first.model, first.role
        findings = [finding for result in seat_results for finding in result.findings]
        contributions.append(
            SeatContribution(
                seat_id=seat_id,
                provider=provider,
                model=model,
                role=role,
                phases=sorted({result.phase for result in seat_results}),
                calls=len(seat_results),
                successful_calls=sum(1 for result in seat_results if not result.error),
                findings=len(findings),
                verified_findings=sum(1 for finding in findings if finding.verified),
                selected_findings=sum(1 for finding in findings if finding.finding_id in selected_ids),
                dissent_mentions=sum(1 for item in dissent if seat_id in item.dissenting_seats),
                latency_ms=sum(result.latency_ms for result in seat_results),
                errors=[str(result.error) for result in seat_results if result.error],
            )
        )
    return contributions


def build_coverage_report(
    selected_seat_ids: list[str],
    contributions: list[SeatContribution],
    clusters: list[ClaimCluster],
    dissent: list[Dissent],
    capability_results: list[CapabilityResult],
    registry: SeatRegistry,
) -> CoverageReport:
    selected = [registry.get(seat_id) for seat_id in selected_seat_ids]
    all_source_refs = {
        ref
        for cluster in clusters
        for ref in (*cluster.validated_source_refs, *cluster.unverified_source_refs)
    }
    valid_source_refs = {ref for cluster in clusters for ref in cluster.validated_source_refs}
    configured_seats = len(registry.enabled_seats)
    return CoverageReport(
        selected_seats=len(selected_seat_ids),
        configured_seats=configured_seats,
        selection_ratio=round(len(selected_seat_ids) / configured_seats, 6) if configured_seats else 0.0,
        successful_seats=sum(1 for item in contributions if item.successful_calls > 0),
        provider_families=sorted({seat.provider_family or seat.provider for seat in selected}),
        independence_groups=sorted(
            {seat.independence_group or seat.provider_family or seat.provider for seat in selected}
        ),
        roles=sorted({seat.role for seat in selected}),
        domains=sorted({domain for seat in selected for domain in seat.domains}),
        evidence_sources=len(all_source_refs),
        validated_evidence_sources=len(valid_source_refs),
        unresolved_dissent=sum(1 for item in dissent if item.vindicated is not False),
        degraded_capabilities=sum(
            1 for item in capability_results if item.status not in {"completed", "skipped"}
        ),
    )
