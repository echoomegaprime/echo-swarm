from __future__ import annotations

import os
from dataclasses import asdict, dataclass, field
from typing import Any

from .config import SeatConfig, SeatRegistry
from .control import CostTable
from .providers import ProviderRegistry, resolve_model_reference


@dataclass(slots=True)
class ProviderReadiness:
    provider: str
    model_reference: str
    model: str | None
    status: str
    ready: bool
    credential_present: bool | None
    pricing_configured: bool
    network_verified: bool
    seat_ids: list[str] = field(default_factory=list)
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class PreflightReport:
    runtime: str
    providers: list[ProviderReadiness]
    planner_ready: bool
    ready_trinity_seats: list[str]
    ready_swarm_seats: list[str]

    @property
    def can_run_live_canary(self) -> bool:
        return self.planner_ready and bool(self.ready_trinity_seats) and bool(self.ready_swarm_seats)

    def to_dict(self) -> dict[str, Any]:
        return {
            "runtime": self.runtime,
            "providers": [item.to_dict() for item in self.providers],
            "planner_ready": self.planner_ready,
            "ready_trinity_seats": list(self.ready_trinity_seats),
            "ready_swarm_seats": list(self.ready_swarm_seats),
            "can_run_live_canary": self.can_run_live_canary,
            "credential_values_exposed": False,
        }


def _credential_environment(adapter: object) -> str | None:
    value = getattr(adapter, "api_key_env", None)
    return str(value) if value else None


async def build_preflight_report(
    registry: SeatRegistry,
    providers: ProviderRegistry,
    costs: CostTable,
    *,
    runtime: str,
) -> PreflightReport:
    if runtime not in {"fake", "live"}:
        raise ValueError("preflight runtime must be fake or live")
    all_seats = (*registry.seats, *registry.trinity, registry.planner)
    groups: dict[tuple[str, str], list[SeatConfig]] = {}
    for seat in all_seats:
        groups.setdefault((seat.provider.lower(), seat.model), []).append(seat)

    readiness: list[ProviderReadiness] = []
    ready_ids: set[str] = set()
    for (provider, model_reference), seats in sorted(groups.items()):
        adapter = providers.adapter_for(provider)
        seat_ids = [seat.id for seat in seats]
        if adapter is None:
            readiness.append(
                ProviderReadiness(
                    provider=provider,
                    model_reference=model_reference,
                    model=None,
                    status="unavailable",
                    ready=False,
                    credential_present=None,
                    pricing_configured=False,
                    network_verified=False,
                    seat_ids=seat_ids,
                    detail="provider adapter is not registered in this runtime",
                )
            )
            continue
        try:
            model = resolve_model_reference(model_reference, resolve_environment=providers.resolve_environment_models)
        except Exception:
            readiness.append(
                ProviderReadiness(
                    provider=provider,
                    model_reference=model_reference,
                    model=None,
                    status="misconfigured",
                    ready=False,
                    credential_present=None,
                    pricing_configured=False,
                    network_verified=False,
                    seat_ids=seat_ids,
                    detail="required model environment reference is missing",
                )
            )
            continue

        credential_env = _credential_environment(adapter)
        credential_present = None if credential_env is None else bool(os.environ.get(credential_env, "").strip())
        if credential_present is False:
            readiness.append(
                ProviderReadiness(
                    provider=provider,
                    model_reference=model_reference,
                    model=model,
                    status="unauthorized",
                    ready=False,
                    credential_present=False,
                    pricing_configured=costs.is_free(provider) or costs.rate_for(provider, model) is not None,
                    network_verified=False,
                    seat_ids=seat_ids,
                    detail=f"credential environment reference is not present: {credential_env}",
                )
            )
            continue

        pricing_configured = costs.is_free(provider) or costs.rate_for(provider, model) is not None
        if runtime == "live" and not pricing_configured:
            readiness.append(
                ProviderReadiness(
                    provider=provider,
                    model_reference=model_reference,
                    model=model,
                    status="blocked_budget",
                    ready=False,
                    credential_present=credential_present,
                    pricing_configured=False,
                    network_verified=False,
                    seat_ids=seat_ids,
                    detail="current pricing is required before a paid live call",
                )
            )
            continue

        network_verified = False
        try:
            probe = getattr(adapter, "probe", None)
            if callable(probe):
                probe_ready = bool(await probe(model))
                if not probe_ready:
                    raise RuntimeError("provider probe did not confirm the configured model/session")
                network_verified = bool(getattr(adapter, "probe_verifies_network", True))
        except Exception as exc:
            readiness.append(
                ProviderReadiness(
                    provider=provider,
                    model_reference=model_reference,
                    model=model,
                    status="unavailable",
                    ready=False,
                    credential_present=credential_present,
                    pricing_configured=pricing_configured,
                    network_verified=False,
                    seat_ids=seat_ids,
                    detail=f"readiness probe failed: {type(exc).__name__}",
                )
            )
            continue

        ready_ids.update(seat_ids)
        readiness.append(
            ProviderReadiness(
                provider=provider,
                model_reference=model_reference,
                model=model,
                status="ready",
                ready=True,
                credential_present=credential_present,
                pricing_configured=pricing_configured,
                network_verified=network_verified,
                seat_ids=seat_ids,
                detail="configuration ready; remote network is verified only when network_verified is true",
            )
        )

    return PreflightReport(
        runtime=runtime,
        providers=readiness,
        planner_ready=registry.planner.id in ready_ids,
        ready_trinity_seats=[seat.id for seat in registry.trinity if seat.id in ready_ids],
        ready_swarm_seats=[seat.id for seat in registry.enabled_seats if seat.id in ready_ids],
    )


def select_canary_seats(report: PreflightReport, registry: SeatRegistry, count: int) -> list[str]:
    if count <= 0:
        raise ValueError("canary seat count must be positive")
    ready = set(report.ready_swarm_seats)
    selected: list[str] = []
    used_providers: set[str] = set()
    for seat in registry.enabled_seats:
        if seat.id in ready and seat.provider not in used_providers:
            selected.append(seat.id)
            used_providers.add(seat.provider)
            if len(selected) >= count:
                return selected
    for seat in registry.enabled_seats:
        if seat.id in ready and seat.id not in selected:
            selected.append(seat.id)
            if len(selected) >= count:
                break
    return selected
