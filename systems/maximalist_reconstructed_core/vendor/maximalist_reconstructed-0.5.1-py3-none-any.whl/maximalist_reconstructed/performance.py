from __future__ import annotations

import asyncio
import json
import os
import tempfile
from pathlib import Path
from typing import Any, Protocol

from .models import HISTORICAL_PARITY, PROFILE_NAME


class PerformanceAdapter(Protocol):
    def snapshot(self) -> dict[str, dict[str, float]]:
        ...

    async def record_run(self, run_id: str, observations: list[dict[str, Any]]) -> list[str]:
        ...


def _empty_store() -> dict[str, Any]:
    return {
        "version": 1,
        "profile": PROFILE_NAME,
        "historical_parity": HISTORICAL_PARITY,
        "observations": {},
        "models": {},
    }


def _validate_store(data: dict[str, Any]) -> dict[str, Any]:
    if data.get("profile", PROFILE_NAME) != PROFILE_NAME or data.get("historical_parity", False) is not False:
        raise ValueError("performance store provenance does not match MAXIMALIST_RECONSTRUCTED")
    if not isinstance(data.get("observations", {}), dict) or not isinstance(data.get("models", {}), dict):
        raise ValueError("performance store has an invalid schema")
    return data


def _recalculate(data: dict[str, Any]) -> None:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for item in data.get("observations", {}).values():
        if isinstance(item, dict) and str(item.get("model") or "").strip():
            grouped.setdefault(str(item["model"]), []).append(item)

    models: dict[str, dict[str, Any]] = {}
    for model, items in grouped.items():
        requests = len(items)
        successes = sum(1 for item in items if bool(item.get("success")))
        findings = sum(max(0, int(item.get("findings", 0))) for item in items)
        verified = sum(max(0, int(item.get("verified_findings", 0))) for item in items)
        latency_values = [max(0, int(item.get("latency_ms", 0))) for item in items]
        smoothed_success = (successes + 1.0) / (requests + 2.0)
        smoothed_verification = (verified + 1.0) / (findings + 2.0)
        domain_score = 0.7 * smoothed_success + 0.3 * smoothed_verification
        domains: dict[str, dict[str, float]] = {}
        for domain in sorted({str(value) for item in items for value in item.get("domains", [])}):
            domain_items = [item for item in items if domain in item.get("domains", [])]
            domain_requests = len(domain_items)
            domain_successes = sum(1 for item in domain_items if bool(item.get("success")))
            domains[domain] = {
                "requests": float(domain_requests),
                "successes": float(domain_successes),
                "domain_score": round((domain_successes + 1.0) / (domain_requests + 2.0), 6),
            }
        models[model] = {
            "requests": float(requests),
            "successes": float(successes),
            "findings": float(findings),
            "verified_findings": float(verified),
            "average_latency_ms": round(sum(latency_values) / max(1, len(latency_values)), 3),
            "domain_score": round(domain_score, 6),
            "domains": domains,
        }
    data["models"] = models


def _normalized_observation(run_id: str, item: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    seat_id = str(item.get("seat_id") or "").strip()
    phase = str(item.get("phase") or "").strip()
    model = str(item.get("model") or "").strip()
    provider = str(item.get("provider") or "").strip()
    if not all((run_id, seat_id, phase, model, provider)):
        raise ValueError("performance observation is missing run, seat, phase, model, or provider")
    observation_id = str(item.get("observation_id") or f"{run_id}:{seat_id}:{phase}")
    normalized = {
        "observation_id": observation_id,
        "run_id": run_id,
        "seat_id": seat_id,
        "provider": provider,
        "model": model,
        "role": str(item.get("role") or ""),
        "domains": sorted({str(value) for value in item.get("domains", []) if str(value)}),
        "phase": phase,
        "success": bool(item.get("success", False)),
        "findings": max(0, int(item.get("findings", 0))),
        "verified_findings": max(0, int(item.get("verified_findings", 0))),
        "latency_ms": max(0, int(item.get("latency_ms", 0))),
    }
    return observation_id, normalized


class InMemoryPerformanceAdapter:
    def __init__(self, seed: dict[str, Any] | None = None) -> None:
        self.data = _validate_store(dict(seed or _empty_store()))
        _recalculate(self.data)
        self.write_attempts: list[str] = []

    def snapshot(self) -> dict[str, dict[str, float]]:
        return {
            model: dict(stats)
            for model, stats in self.data.get("models", {}).items()
            if isinstance(stats, dict)
        }

    async def record_run(self, run_id: str, observations: list[dict[str, Any]]) -> list[str]:
        self.write_attempts.append(run_id)
        records = self.data.setdefault("observations", {})
        receipts: list[str] = []
        for item in observations:
            observation_id, normalized = _normalized_observation(run_id, item)
            records[observation_id] = normalized
            receipts.append(f"performance:{observation_id}")
        _recalculate(self.data)
        return receipts


class JsonFilePerformanceAdapter:
    """Atomic, idempotent performance observations keyed by run/seat/phase."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = asyncio.Lock()

    def _read(self) -> dict[str, Any]:
        if not self.path.exists():
            return _empty_store()
        with self.path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        if not isinstance(value, dict):
            raise ValueError("performance file has an invalid schema")
        return _validate_store(value)

    def _atomic_write(self, data: dict[str, Any]) -> None:
        descriptor, temporary = tempfile.mkstemp(
            prefix=f".{self.path.name}.", suffix=".tmp", dir=self.path.parent
        )
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
                json.dump(data, handle, indent=2, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def snapshot(self) -> dict[str, dict[str, float]]:
        data = self._read()
        _recalculate(data)
        return {
            model: dict(stats)
            for model, stats in data.get("models", {}).items()
            if isinstance(stats, dict)
        }

    async def record_run(self, run_id: str, observations: list[dict[str, Any]]) -> list[str]:
        async with self._lock:
            data = await asyncio.to_thread(self._read)
            records = data.setdefault("observations", {})
            receipts: list[str] = []
            for item in observations:
                observation_id, normalized = _normalized_observation(run_id, item)
                records[observation_id] = normalized
                receipts.append(f"performance:{observation_id}")
            _recalculate(data)
            await asyncio.to_thread(self._atomic_write, data)
        return receipts
